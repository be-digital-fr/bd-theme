(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/41da7_next_471d56eb._.js",
  "static/chunks/a7cec_@zod_core_dist_esm_8a178cb4._.js",
  "static/chunks/b2692_react-icons_fi_index_mjs_97a1e284._.js",
  "static/chunks/b2692_react-icons_bi_index_mjs_e6a2fd56._.js",
  "static/chunks/b2692_react-icons_lib_d4addfaa._.js",
  "static/chunks/node_modules__pnpm_bf021304._.js",
  "static/chunks/_ffb02c04._.js"
],
    source: "dynamic"
});
