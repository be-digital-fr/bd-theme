(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules__pnpm_031cd15a._.js",
  "static/chunks/_1d2aabdd._.js"
],
    source: "dynamic"
});
