(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_bfe22f01._.js",
  "static/chunks/41da7_next_dist_compiled_4ddc92e6._.js",
  "static/chunks/41da7_next_dist_client_788a8977._.js",
  "static/chunks/41da7_next_dist_54e00b1b._.js",
  "static/chunks/61dca_@swc_helpers_cjs_e27e0aca._.js"
],
    source: "entry"
});
