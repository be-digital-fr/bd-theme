(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "$ZodAsyncError": (()=>$ZodAsyncError),
    "$brand": (()=>$brand),
    "$constructor": (()=>$constructor),
    "config": (()=>config),
    "globalConfig": (()=>globalConfig)
});
/*@__NO_SIDE_EFFECTS__*/ function $constructor(name, initializer) {
    class _ {
        constructor(def){
            var _a;
            const th = this;
            _.init(th, def);
            (_a = th._zod).deferred ?? (_a.deferred = []);
            for (const fn of th._zod.deferred){
                fn();
            }
        }
        static init(inst, def) {
            var _a;
            inst._zod ?? (inst._zod = {});
            (_a = inst._zod).traits ?? (_a.traits = new Set());
            // const seen = inst._zod.traits.has(name);
            inst._zod.traits.add(name);
            initializer(inst, def);
            // support prototype modifications
            for(const k in _.prototype){
                Object.defineProperty(inst, k, {
                    value: _.prototype[k].bind(inst)
                });
            }
            inst._zod.constr = _;
            inst._zod.def = def;
        }
        static [Symbol.hasInstance](inst) {
            return inst?._zod?.traits?.has(name);
        }
    }
    Object.defineProperty(_, "name", {
        value: name
    });
    return _;
}
const $brand = Symbol("zod_brand");
class $ZodAsyncError extends Error {
    constructor(){
        super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
    }
}
const globalConfig = {};
function config(config) {
    if (config) Object.assign(globalConfig, config);
    return globalConfig;
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// functions
__turbopack_context__.s({
    "BIGINT_FORMAT_RANGES": (()=>BIGINT_FORMAT_RANGES),
    "NUMBER_FORMAT_RANGES": (()=>NUMBER_FORMAT_RANGES),
    "aborted": (()=>aborted),
    "allowsEval": (()=>allowsEval),
    "assert": (()=>assert),
    "assertEqual": (()=>assertEqual),
    "assertIs": (()=>assertIs),
    "assertNever": (()=>assertNever),
    "assertNotEqual": (()=>assertNotEqual),
    "assignProp": (()=>assignProp),
    "cached": (()=>cached),
    "cleanInterfaceKey": (()=>cleanInterfaceKey),
    "cleanInterfaceShape": (()=>cleanInterfaceShape),
    "cleanRegex": (()=>cleanRegex),
    "clone": (()=>clone),
    "createTransparentProxy": (()=>createTransparentProxy),
    "defineLazy": (()=>defineLazy),
    "esc": (()=>esc),
    "escapeRegex": (()=>escapeRegex),
    "extend": (()=>extend),
    "extendObjectLike": (()=>extendObjectLike),
    "finalizeIssue": (()=>finalizeIssue),
    "floatSafeRemainder": (()=>floatSafeRemainder),
    "getElementAtPath": (()=>getElementAtPath),
    "getLengthableOrigin": (()=>getLengthableOrigin),
    "getParsedType": (()=>getParsedType),
    "getSizableOrigin": (()=>getSizableOrigin),
    "getValidEnumValues": (()=>getValidEnumValues),
    "isObject": (()=>isObject),
    "isPlainObject": (()=>isPlainObject),
    "issue": (()=>issue),
    "joinValues": (()=>joinValues),
    "jsonStringifyReplacer": (()=>jsonStringifyReplacer),
    "mergeObjectLike": (()=>mergeObjectLike),
    "normalizeObjectLikeDef": (()=>normalizeObjectLikeDef),
    "normalizeParams": (()=>normalizeParams),
    "nullish": (()=>nullish),
    "numKeys": (()=>numKeys),
    "omit": (()=>omit),
    "optionalInterfaceKeys": (()=>optionalInterfaceKeys),
    "optionalObjectKeys": (()=>optionalObjectKeys),
    "partialObjectLike": (()=>partialObjectLike),
    "pick": (()=>pick),
    "prefixIssues": (()=>prefixIssues),
    "primitiveTypes": (()=>primitiveTypes),
    "promiseAllObject": (()=>promiseAllObject),
    "propertyKeyTypes": (()=>propertyKeyTypes),
    "randomString": (()=>randomString),
    "requiredObjectLike": (()=>requiredObjectLike),
    "splitChecksAndParams": (()=>splitChecksAndParams),
    "stringifyPrimitive": (()=>stringifyPrimitive),
    "unwrapMessage": (()=>unwrapMessage)
});
function assertEqual(val) {
    return val;
}
function assertNotEqual(val) {
    return val;
}
function assertIs(_arg) {}
function assertNever(_x) {
    throw new Error();
}
function assert(_) {}
function getValidEnumValues(obj) {
    const validKeys = Object.keys(obj).filter((k)=>typeof obj[obj[k]] !== "number");
    const filtered = {};
    for (const k of validKeys){
        filtered[k] = obj[k];
    }
    return Object.values(filtered);
}
function joinValues(array, separator = "|") {
    return array.map((val)=>stringifyPrimitive(val)).join(separator);
}
function jsonStringifyReplacer(_, value) {
    if (typeof value === "bigint") return value.toString();
    return value;
}
function cached(getter) {
    const set = false;
    return {
        get value () {
            if ("TURBOPACK compile-time truthy", 1) {
                const value = getter();
                Object.defineProperty(this, "value", {
                    value
                });
                return value;
            }
            "TURBOPACK unreachable";
        }
    };
}
function nullish(input) {
    return input === null || input === undefined;
}
function cleanRegex(source) {
    const start = source.startsWith("^") ? 1 : 0;
    const end = source.endsWith("$") ? source.length - 1 : source.length;
    return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
    const valDecCount = (val.toString().split(".")[1] || "").length;
    const stepDecCount = (step.toString().split(".")[1] || "").length;
    const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
    const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
    const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
    return valInt % stepInt / 10 ** decCount;
}
function defineLazy(object, key, getter) {
    const set = false;
    Object.defineProperty(object, key, {
        get () {
            if ("TURBOPACK compile-time truthy", 1) {
                const value = getter();
                object[key] = value;
                // Object.defineProperty(object, key, { value });
                return value;
            }
            "TURBOPACK unreachable";
        },
        set (v) {
            Object.defineProperty(object, key, {
                value: v
            });
        // object[key] = v;
        },
        configurable: true
    });
}
function assignProp(target, prop, value) {
    Object.defineProperty(target, prop, {
        value,
        writable: true,
        enumerable: true,
        configurable: true
    });
}
function getElementAtPath(obj, path) {
    if (!path) return obj;
    return path.reduce((acc, key)=>acc?.[key], obj);
}
function promiseAllObject(promisesObj) {
    const keys = Object.keys(promisesObj);
    const promises = keys.map((key)=>promisesObj[key]);
    return Promise.all(promises).then((results)=>{
        const resolvedObj = {};
        for(let i = 0; i < keys.length; i++){
            resolvedObj[keys[i]] = results[i];
        }
        return resolvedObj;
    });
}
function randomString(length = 10) {
    const chars = "abcdefghijklmnopqrstuvwxyz";
    let str = "";
    for(let i = 0; i < length; i++){
        str += chars[Math.floor(Math.random() * chars.length)];
    }
    return str;
}
function esc(str) {
    return JSON.stringify(str);
}
function isObject(data) {
    return typeof data === "object" && data !== null;
}
const allowsEval = cached(()=>{
    try {
        new Function("");
        return true;
    } catch (_) {
        return false;
    }
});
function isPlainObject(data) {
    return typeof data === "object" && data !== null && Object.getPrototypeOf(data) === Object.prototype;
}
function numKeys(data) {
    let keyCount = 0;
    for(const key in data){
        if (Object.prototype.hasOwnProperty.call(data, key)) {
            keyCount++;
        }
    }
    return keyCount;
}
const getParsedType = (data)=>{
    const t = typeof data;
    switch(t){
        case "undefined":
            return "undefined";
        case "string":
            return "string";
        case "number":
            return Number.isNaN(data) ? "nan" : "number";
        case "boolean":
            return "boolean";
        case "function":
            return "function";
        case "bigint":
            return "bigint";
        case "symbol":
            return "symbol";
        case "object":
            if (Array.isArray(data)) {
                return "array";
            }
            if (data === null) {
                return "null";
            }
            if (data.then && typeof data.then === "function" && data.catch && typeof data.catch === "function") {
                return "promise";
            }
            if (typeof Map !== "undefined" && data instanceof Map) {
                return "map";
            }
            if (typeof Set !== "undefined" && data instanceof Set) {
                return "set";
            }
            if (typeof Date !== "undefined" && data instanceof Date) {
                return "date";
            }
            if (typeof File !== "undefined" && data instanceof File) {
                return "file";
            }
            return "object";
        default:
            throw new Error(`Unknown data type: ${t}`);
    }
};
const propertyKeyTypes = new Set([
    "string",
    "number",
    "symbol"
]);
const primitiveTypes = new Set([
    "string",
    "number",
    "bigint",
    "boolean",
    "symbol",
    "undefined"
]);
function escapeRegex(str) {
    return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def) {
    return new inst._zod.constr(def);
}
function splitChecksAndParams(_paramsOrChecks, _checks) {
    const params = Array.isArray(_paramsOrChecks) ? {} : _paramsOrChecks ?? {};
    const checks = Array.isArray(_paramsOrChecks) ? _paramsOrChecks : _checks ?? [];
    return {
        checks,
        params
    };
}
function normalizeParams(_params) {
    const params = _params;
    if (!params) return {};
    if (typeof params === "string") return {
        error: ()=>params
    };
    if (params?.message !== undefined) {
        if (params?.error !== undefined) throw new Error("Cannot specify both `message` and `error` params");
        params.error = params.message;
    }
    delete params.message;
    if (typeof params.error === "string") return {
        ...params,
        error: ()=>params.error
    };
    return params;
}
function createTransparentProxy(getter) {
    let target;
    return new Proxy({}, {
        get (_, prop, receiver) {
            target ?? (target = getter());
            return Reflect.get(target, prop, receiver);
        },
        set (_, prop, value, receiver) {
            target ?? (target = getter());
            return Reflect.set(target, prop, value, receiver);
        },
        has (_, prop) {
            target ?? (target = getter());
            return Reflect.has(target, prop);
        },
        deleteProperty (_, prop) {
            target ?? (target = getter());
            return Reflect.deleteProperty(target, prop);
        },
        ownKeys (_) {
            target ?? (target = getter());
            return Reflect.ownKeys(target);
        },
        getOwnPropertyDescriptor (_, prop) {
            target ?? (target = getter());
            return Reflect.getOwnPropertyDescriptor(target, prop);
        },
        defineProperty (_, prop, descriptor) {
            target ?? (target = getter());
            return Reflect.defineProperty(target, prop, descriptor);
        }
    });
}
function stringifyPrimitive(value) {
    if (typeof value === "bigint") return value.toString() + "n";
    if (typeof value === "string") return `"${value}"`;
    return `${value}`;
}
function optionalObjectKeys(shape) {
    return Object.keys(shape).filter((k)=>{
        return shape[k]._zod.qout === "true";
    });
}
function optionalInterfaceKeys(shape) {
    return Object.keys(shape).filter((k)=>{
        return k.endsWith("?");
    }).map((k)=>k.replace(/\?$/, ""));
}
function cleanInterfaceKey(key) {
    return key.replace(/^\?/, "").replace(/\?$/, "");
}
function cleanInterfaceShape(_shape) {
    const keyMap = {};
    const shape = {};
    const optional = [];
    const defaulted = [];
    for (const [key, value] of Object.entries(_shape)){
        if (key.endsWith("?")) optional.push(key.slice(0, -1));
        if (key.startsWith("?")) defaulted.push(key.slice(1));
        const cleanKey = cleanInterfaceKey(key);
        shape[cleanKey] = value;
        keyMap[cleanKey] = key;
    }
    return {
        shape,
        keyMap,
        optional,
        defaulted
    };
}
const NUMBER_FORMAT_RANGES = {
    safeint: [
        Number.MIN_SAFE_INTEGER,
        Number.MAX_SAFE_INTEGER
    ],
    int32: [
        -2147483648,
        2147483647
    ],
    uint32: [
        0,
        4294967295
    ],
    float32: [
        -3.4028234663852886e38,
        3.4028234663852886e38
    ],
    float64: [
        -1.7976931348623157e308,
        1.7976931348623157e308
    ]
};
const BIGINT_FORMAT_RANGES = {
    int64: [
        /* @__PURE__*/ BigInt("-9223372036854775808"),
        /* @__PURE__*/ BigInt("9223372036854775807")
    ],
    uint64: [
        /* @__PURE__*/ BigInt(0),
        /* @__PURE__*/ BigInt("18446744073709551615")
    ]
};
function pick(schema, mask) {
    const newShape = {};
    const newOptional = [];
    const currShape = schema._zod.def.shape;
    const currOptional = new Set(schema._zod.def.optional);
    // const currDefaulted = new Set(schema._zod.def.defaulted);
    for(const key in mask){
        if (!(key in currShape)) {
            throw new Error(`Unrecognized key: "${key}"`);
        }
        if (!mask[key]) continue;
        // pick key
        newShape[key] = currShape[key];
        if (currOptional.has(key)) {
            newOptional.push(key);
        }
    }
    return clone(schema, {
        ...schema._zod.def,
        shape: newShape,
        optional: newOptional,
        checks: []
    });
}
function omit(schema, mask) {
    const newShape = {
        ...schema._zod.def.shape
    };
    const newOptional = new Set(schema._zod.def.optional);
    for(const key in mask){
        if (!(key in schema._zod.def.shape)) {
            throw new Error(`Unrecognized key: "${key}"`);
        }
        if (!mask[key]) continue;
        delete newShape[key];
        newOptional.delete(key);
    }
    return clone(schema, {
        ...schema._zod.def,
        shape: newShape,
        optional: [
            ...newOptional
        ],
        checks: []
    });
}
function extend(schema, shape) {
    const def = {
        ...schema._zod.def,
        get shape () {
            const _shape = {
                ...schema._zod.def.shape,
                ...shape
            };
            assignProp(this, "shape", _shape);
            return _shape;
        },
        checks: []
    };
    defineLazy(def, "shape", ()=>({
            ...schema._zod.def.shape,
            ...shape
        }));
    return clone(schema, def);
}
function mergeObjectLike(a, b) {
    const bKeys = new Set(Object.keys(b._zod.def.shape));
    const optional = [
        ...a._zod.def.optional.filter((k)=>!bKeys.has(k)),
        ...b._zod.def.optional
    ];
    return clone(a, {
        ...a._zod.def,
        get shape () {
            const _shape = {
                ...a._zod.def.shape,
                ...b._zod.def.shape
            };
            assignProp(this, "shape", _shape);
            return _shape;
        // return { ...a._zod.def.shape, ...b._zod.def.shape };
        },
        optional,
        catchall: b._zod.def.catchall,
        checks: []
    });
}
function extendObjectLike(a, b) {
    const bKeys = new Set(Object.keys(b._zod.def.shape));
    const optional = [
        ...a._zod.def.optional.filter((k)=>!bKeys.has(k)),
        ...b._zod.def.optional
    ];
    return clone(a, {
        ...a._zod.def,
        get shape () {
            const _shape = {
                ...a._zod.def.shape,
                ...b._zod.def.shape
            };
            assignProp(this, "shape", _shape);
            return _shape;
        // return { ...a._zod.def.shape, ...b._zod.def.shape };
        },
        optional,
        checks: []
    });
}
function partialObjectLike(Class, schema, mask) {
    const shape = {
        ...schema._zod.def.shape
    };
    const optional = new Set(schema._zod.def.optional);
    if (mask) {
        for(const key in mask){
            if (!(key in shape)) {
                throw new Error(`Unrecognized key: "${key}"`);
            }
            if (!mask[key]) continue;
            shape[key] = new Class({
                type: "optional",
                innerType: schema._zod.def.shape[key]
            });
            optional.add(key);
        }
    } else {
        for(const key in schema._zod.def.shape){
            shape[key] = new Class({
                type: "optional",
                innerType: schema._zod.def.shape[key]
            });
            optional.add(key);
        }
    }
    return clone(schema, {
        ...schema._zod.def,
        shape,
        optional: [
            ...optional
        ],
        checks: []
    });
}
function requiredObjectLike(Class, schema, mask) {
    const shape = {
        ...schema._zod.def.shape
    };
    if (mask) {
        for(const key in mask){
            if (!(key in shape)) {
                throw new Error(`Unrecognized key: "${key}"`);
            }
            if (!mask[key]) continue;
            // overwrite with non-optional
            shape[key] = new Class({
                type: "nonoptional",
                innerType: schema._zod.def.shape[key]
            });
        }
    } else {
        for(const key in schema._zod.def.shape){
            // overwrite with non-optional
            shape[key] = new Class({
                type: "nonoptional",
                innerType: schema._zod.def.shape[key]
            });
        }
    }
    return clone(schema, {
        ...schema._zod.def,
        shape,
        optional: [],
        checks: []
    });
}
function normalizeObjectLikeDef(def) {
    if (def.type === "interface") {
        const keys = Object.keys(def.shape);
        const keySet = new Set(Object.keys(def.shape));
        return {
            shape: {
                ...def.shape
            },
            keys,
            keySet,
            numKeys: keys.length,
            optionalKeys: new Set(def.optional)
        };
    }
    if (def.type === "object") {
        const keys = Object.keys(def.shape);
        const keySet = new Set(Object.keys(def.shape));
        return {
            shape: {
                ...def.shape
            },
            keys,
            keySet,
            numKeys: keys.length,
            optionalKeys: new Set(def.optional)
        };
    }
    throw new Error("Invalid object-like type");
}
function aborted(x, startIndex = 0) {
    for(let i = startIndex; i < x.issues.length; i++){
        if (x.issues[i].continue !== true) return true;
    }
    return false;
}
function prefixIssues(path, issues) {
    return issues.map((iss)=>{
        var _a;
        (_a = iss).path ?? (_a.path = []);
        iss.path.unshift(path);
        return iss;
    });
}
function unwrapMessage(message) {
    return typeof message === "string" ? message : message?.message;
}
function finalizeIssue(iss, ctx, config) {
    const full = {
        ...iss,
        path: iss.path ?? []
    };
    // for backwards compatibility
    // const _ctx: errors.$ZodErrorMapCtx = { data: iss.input, defaultError: undefined as any };
    if (!iss.message) {
        const message = unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
        full.message = message;
    }
    // delete (full as any).def;
    delete full.inst;
    delete full.continue;
    if (!ctx?.reportInput) {
        delete full.input;
    }
    return full;
}
function getSizableOrigin(input) {
    if (input instanceof Set) return "set";
    if (input instanceof Map) return "map";
    if (input instanceof File) return "file";
    return "unknown";
}
function getLengthableOrigin(input) {
    if (Array.isArray(input)) return "array";
    if (typeof input === "string") return "string";
    return "unknown";
}
function issue(...args) {
    const [iss, input, inst] = args;
    if (typeof iss === "string") {
        return {
            message: iss,
            code: "custom",
            input,
            inst
        };
    }
    return {
        ...iss
    };
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/errors.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "$ZodError": (()=>$ZodError),
    "flattenError": (()=>flattenError),
    "formatError": (()=>formatError),
    "prettifyError": (()=>prettifyError),
    "toDotPath": (()=>toDotPath),
    "treeifyError": (()=>treeifyError)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
////////////////////////    ERROR CLASS   ////////////////////////
const ZOD_ERROR = Symbol.for("{{zod.error}}");
class $ZodError {
    get message() {
        return JSON.stringify(this.issues, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsonStringifyReplacer"], 2);
    }
    constructor(issues){
        Object.defineProperty(this, "_tag", {
            value: ZOD_ERROR,
            enumerable: false
        });
        Object.defineProperty(this, "name", {
            value: "$ZodError",
            enumerable: false
        });
        this.issues = issues;
    }
    // @ts-ignore
    static [Symbol.hasInstance](inst) {
        return inst?._tag === ZOD_ERROR;
    }
}
function flattenError(error, mapper = (issue)=>issue.message) {
    const fieldErrors = {};
    const formErrors = [];
    for (const sub of error.issues){
        if (sub.path.length > 0) {
            fieldErrors[sub.path[0]] = fieldErrors[sub.path[0]] || [];
            fieldErrors[sub.path[0]].push(mapper(sub));
        } else {
            formErrors.push(mapper(sub));
        }
    }
    return {
        formErrors,
        fieldErrors
    };
}
function formatError(error, _mapper) {
    const mapper = _mapper || function(issue) {
        return issue.message;
    };
    const fieldErrors = {
        _errors: []
    };
    const processError = (error)=>{
        for (const issue of error.issues){
            if (issue.code === "invalid_union") {
                issue.errors.map((issues)=>processError({
                        issues
                    }));
            } else if (issue.code === "invalid_key") {
                processError({
                    issues: issue.issues
                });
            } else if (issue.code === "invalid_element") {
                processError({
                    issues: issue.issues
                });
            } else if (issue.path.length === 0) {
                fieldErrors._errors.push(mapper(issue));
            } else {
                let curr = fieldErrors;
                let i = 0;
                while(i < issue.path.length){
                    const el = issue.path[i];
                    const terminal = i === issue.path.length - 1;
                    if (!terminal) {
                        curr[el] = curr[el] || {
                            _errors: []
                        };
                    } else {
                        curr[el] = curr[el] || {
                            _errors: []
                        };
                        curr[el]._errors.push(mapper(issue));
                    }
                    curr = curr[el];
                    i++;
                }
            }
        }
    };
    processError(error);
    return fieldErrors;
}
function treeifyError(error, _mapper) {
    const mapper = _mapper || function(issue) {
        return issue.message;
    };
    const result = {
        errors: []
    };
    const processError = (error)=>{
        var _a, _b;
        for (const issue of error.issues){
            if (issue.code === "invalid_union") {
                issue.errors.map((issues)=>processError({
                        issues
                    }));
            } else if (issue.code === "invalid_key") {
                processError({
                    issues: issue.issues
                });
            } else if (issue.code === "invalid_element") {
                processError({
                    issues: issue.issues
                });
            } else if (issue.path.length === 0) {
                result.errors.push(mapper(issue));
            } else {
                let curr = result;
                let i = 0;
                while(i < issue.path.length){
                    const el = issue.path[i];
                    const terminal = i === issue.path.length - 1;
                    if (typeof el === "string") {
                        curr.properties ?? (curr.properties = {});
                        (_a = curr.properties)[el] ?? (_a[el] = {
                            errors: []
                        });
                        curr = curr.properties[el];
                    } else {
                        curr.items ?? (curr.items = []);
                        (_b = curr.items)[el] ?? (_b[el] = {
                            errors: []
                        });
                        curr = curr.items[el];
                    }
                    if (terminal) {
                        curr.errors.push(mapper(issue));
                    }
                    // curr = curr.properties[el];
                    // const terminal = i === issue.path.length - 1;
                    // if (!curr) {
                    //   if (typeof el === "string") {
                    //     result.properties = {};
                    //   } else {
                    //     (result as any).properties = [];
                    //   }
                    // }
                    // // const curr: any = result.properties;
                    // if (!terminal) {
                    //   curr[el] = curr[el] || { errors: [] };
                    // } else {
                    //   curr[el] = curr[el] || { errors: [] };
                    //   curr[el].errors.push(mapper(issue));
                    // }
                    // curr = curr[el];
                    // curr = curr.properties[el];
                    i++;
                }
            }
        }
    };
    processError(error);
    return result;
}
function toDotPath(path) {
    const segs = [];
    for (const seg of path){
        if (typeof seg === "number") segs.push(`[${seg}]`);
        else if (typeof seg === "symbol") segs.push(`["${String(seg)}"]`);
        else if (seg.includes(".")) segs.push(`["${seg}"]`);
        else {
            if (segs.length) segs.push(".");
            segs.push(seg);
        }
    }
    return segs.join("");
}
function prettifyError(error) {
    // Create a Map to group issues by path
    // const issuesMap = new Map<string, string[]>();
    const lines = [];
    // issuesMap.set("", []);
    // if(error.issues.every(issue => issue.path.length === 0)) {
    //   return error.issues.map(issue => `✖ ${issue.message}`).join("\n");
    // }
    // sort by path length
    const issues = [
        ...error.issues
    ].sort((a, b)=>a.path.length - b.path.length);
    // Process each issue
    for (const issue of issues){
        lines.push(`✖ ${issue.message}`);
        if (issue.path?.length) lines.push(`  → at ${toDotPath(issue.path)}`);
    }
    // Convert Map to formatted string
    return lines.join("\n");
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/parse.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "_parse": (()=>_parse),
    "_parseAsync": (()=>_parseAsync),
    "_safeParse": (()=>_safeParse),
    "_safeParseAsync": (()=>_safeParseAsync),
    "parse": (()=>parse),
    "parseAsync": (()=>parseAsync),
    "safeParse": (()=>safeParse),
    "safeParseAsync": (()=>safeParseAsync)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
;
;
function _parse(schema, value, _ctx) {
    const ctx = _ctx ? {
        ..._ctx,
        async: false
    } : {
        async: false
    };
    const result = schema._zod.run({
        value,
        issues: []
    }, ctx);
    if (result instanceof Promise) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodAsyncError"]();
    }
    if (result.issues.length) {
        throw new (this?.Error ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"])(result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())));
    }
    return result.value;
}
const parse = /* @__PURE__*/ _parse.bind({
    Error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"]
});
function _safeParse(schema, value, _ctx) {
    const ctx = _ctx ? {
        ..._ctx,
        async: false
    } : {
        async: false
    };
    const result = schema._zod.run({
        value,
        issues: []
    }, ctx);
    if (result instanceof Promise) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodAsyncError"]();
    }
    return result.issues.length ? {
        success: false,
        error: new (this?.Error ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"])(result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())))
    } : {
        success: true,
        data: result.value
    };
}
const safeParse = /* @__PURE__*/ _safeParse.bind({
    Error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"]
});
async function _parseAsync(schema, value, _ctx) {
    const ctx = _ctx ? {
        ..._ctx,
        async: true
    } : {
        async: true
    };
    let result = schema._zod.run({
        value,
        issues: []
    }, ctx);
    if (result instanceof Promise) result = await result;
    if (result.issues.length) {
        throw new (this?.Error ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"])(result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())));
    }
    return result.value;
}
const parseAsync = /* @__PURE__*/ _parseAsync.bind({
    Error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"]
});
async function _safeParseAsync(schema, value, _ctx) {
    const ctx = _ctx ? {
        ..._ctx,
        async: true
    } : {
        async: true
    };
    let result = schema._zod.run({
        value,
        issues: []
    }, ctx);
    if (result instanceof Promise) result = await result;
    if (result.issues.length) {
        return {
            success: false,
            error: new (this?.Error ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"])(result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())))
        };
    }
    return {
        success: true,
        data: result.value
    };
}
const safeParseAsync = /* @__PURE__*/ _safeParseAsync.bind({
    Error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodError"]
});
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "_emoji": (()=>_emoji),
    "base64": (()=>base64),
    "base64url": (()=>base64url),
    "bigint": (()=>bigint),
    "boolean": (()=>boolean),
    "browserEmail": (()=>browserEmail),
    "cidrv4": (()=>cidrv4),
    "cidrv6": (()=>cidrv6),
    "cuid": (()=>cuid),
    "cuid2": (()=>cuid2),
    "date": (()=>date),
    "datetime": (()=>datetime),
    "duration": (()=>duration),
    "e164": (()=>e164),
    "email": (()=>email),
    "emoji": (()=>emoji),
    "extendedDuration": (()=>extendedDuration),
    "guid": (()=>guid),
    "hostname": (()=>hostname),
    "html5Email": (()=>html5Email),
    "integer": (()=>integer),
    "ip": (()=>ip),
    "ipv4": (()=>ipv4),
    "ipv6": (()=>ipv6),
    "ksuid": (()=>ksuid),
    "lowercase": (()=>lowercase),
    "nanoid": (()=>nanoid),
    "null": (()=>_null),
    "number": (()=>number),
    "rfc5322Email": (()=>rfc5322Email),
    "string": (()=>string),
    "time": (()=>time),
    "ulid": (()=>ulid),
    "undefined": (()=>_undefined),
    "unicodeEmail": (()=>unicodeEmail),
    "uppercase": (()=>uppercase),
    "uuid": (()=>uuid),
    "uuid4": (()=>uuid4),
    "uuid6": (()=>uuid6),
    "uuid7": (()=>uuid7),
    "xid": (()=>xid)
});
const cuid = /^[cC][^\s-]{8,}$/;
const cuid2 = /^[0-9a-z]+$/;
const ulid = /^[0-9A-HJKMNP-TV-Z]{26}$/;
const xid = /^[0-9a-vA-V]{20}$/;
const ksuid = /^[A-Za-z0-9]{27}$/;
const nanoid = /^[a-zA-Z0-9_-]{21}$/;
const duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
const extendedDuration = /^[-+]?P(?!$)(?:(?:[-+]?\d+Y)|(?:[-+]?\d+[.,]\d+Y$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:(?:[-+]?\d+W)|(?:[-+]?\d+[.,]\d+W$))?(?:(?:[-+]?\d+D)|(?:[-+]?\d+[.,]\d+D$))?(?:T(?=[\d+-])(?:(?:[-+]?\d+H)|(?:[-+]?\d+[.,]\d+H$))?(?:(?:[-+]?\d+M)|(?:[-+]?\d+[.,]\d+M$))?(?:[-+]?\d+(?:[.,]\d+)?S)?)??$/;
const guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
const uuid = (version)=>{
    if (!version) return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000)$/;
    return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
const uuid4 = uuid(4);
const uuid6 = uuid(6);
const uuid7 = uuid(7);
const email = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
const html5Email = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const rfc5322Email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
const unicodeEmail = /^[^\s@"]{1,64}@[^\s@]{1,255}$/u;
const browserEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
const _emoji = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
function emoji() {
    return new RegExp(_emoji, "u");
}
const ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
const ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})$/;
const cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
const cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
const ip = new RegExp(`(${ipv4.source})|(${ipv6.source})`);
const base64 = /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/;
const base64url = /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/;
const hostname = /^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9])\.)+([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\-]*[A-Za-z0-9])$/;
const e164 = /^\+(?:[0-9]){6,14}[0-9]$/;
const dateSource = `((\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-((0[13578]|1[02])-(0[1-9]|[12]\\d|3[01])|(0[469]|11)-(0[1-9]|[12]\\d|30)|(02)-(0[1-9]|1\\d|2[0-8])))`;
const date = new RegExp(`^${dateSource}$`);
function timeSource(args) {
    // let regex = `\\d{2}:\\d{2}:\\d{2}`;
    let regex = `([01]\\d|2[0-3]):[0-5]\\d:[0-5]\\d`;
    if (args.precision) {
        regex = `${regex}\\.\\d{${args.precision}}`;
    } else if (args.precision == null) {
        regex = `${regex}(\\.\\d+)?`;
    }
    return regex;
}
function time(args) {
    return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
    let regex = `${dateSource}T${timeSource(args)}`;
    const opts = [];
    opts.push(args.local ? `Z?` : `Z`);
    if (args.offset) opts.push(`([+-]\\d{2}:?\\d{2})`);
    regex = `${regex}(${opts.join("|")})`;
    return new RegExp(`^${regex}$`);
}
const string = (params)=>{
    const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
    return new RegExp(`^${regex}$`);
};
const bigint = /^\d+n?$/;
const integer = /^\d+$/;
const number = /^-?\d+(?:\.\d+)?/i;
const boolean = /true|false/i;
const _null = /null/i;
;
const _undefined = /undefined/i;
;
const lowercase = /^[^A-Z]*$/;
const uppercase = /^[^a-z]*$/;
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// import { $ZodType } from "./schemas.js";
__turbopack_context__.s({
    "$ZodCheck": (()=>$ZodCheck),
    "$ZodCheckBigIntFormat": (()=>$ZodCheckBigIntFormat),
    "$ZodCheckEndsWith": (()=>$ZodCheckEndsWith),
    "$ZodCheckGreaterThan": (()=>$ZodCheckGreaterThan),
    "$ZodCheckIncludes": (()=>$ZodCheckIncludes),
    "$ZodCheckLengthEquals": (()=>$ZodCheckLengthEquals),
    "$ZodCheckLessThan": (()=>$ZodCheckLessThan),
    "$ZodCheckLowerCase": (()=>$ZodCheckLowerCase),
    "$ZodCheckMaxLength": (()=>$ZodCheckMaxLength),
    "$ZodCheckMaxSize": (()=>$ZodCheckMaxSize),
    "$ZodCheckMimeType": (()=>$ZodCheckMimeType),
    "$ZodCheckMinLength": (()=>$ZodCheckMinLength),
    "$ZodCheckMinSize": (()=>$ZodCheckMinSize),
    "$ZodCheckMultipleOf": (()=>$ZodCheckMultipleOf),
    "$ZodCheckNumberFormat": (()=>$ZodCheckNumberFormat),
    "$ZodCheckOverwrite": (()=>$ZodCheckOverwrite),
    "$ZodCheckProperty": (()=>$ZodCheckProperty),
    "$ZodCheckRegex": (()=>$ZodCheckRegex),
    "$ZodCheckSizeEquals": (()=>$ZodCheckSizeEquals),
    "$ZodCheckStartsWith": (()=>$ZodCheckStartsWith),
    "$ZodCheckStringFormat": (()=>$ZodCheckStringFormat),
    "$ZodCheckUpperCase": (()=>$ZodCheckUpperCase)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
;
;
const $ZodCheck = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheck", (inst, def)=>{
    var _a;
    inst._zod ?? (inst._zod = {});
    inst._zod.def = def;
    (_a = inst._zod).onattach ?? (_a.onattach = []);
});
const numericOriginMap = {
    number: "number",
    bigint: "bigint",
    object: "date"
};
const $ZodCheckLessThan = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckLessThan", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const origin = numericOriginMap[typeof def.value];
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.maximum ?? Number.POSITIVE_INFINITY;
        if (def.value < curr) {
            inst._zod.computed.maximum = def.value;
            inst._zod.computed.inclusive = def.inclusive;
        }
    });
    inst._zod.check = (payload)=>{
        if (def.inclusive ? payload.value <= def.value : payload.value < def.value) {
            return;
        }
        payload.issues.push({
            origin,
            code: "too_big",
            maximum: def.value,
            input: payload.value,
            inclusive: def.inclusive,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckGreaterThan = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckGreaterThan", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const origin = numericOriginMap[typeof def.value];
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.minimum ?? Number.NEGATIVE_INFINITY;
        if (def.value > curr) {
            inst._zod.computed.minimum = def.value;
            inst._zod.computed.inclusive = def.inclusive;
        }
    });
    inst._zod.check = (payload)=>{
        if (def.inclusive ? payload.value >= def.value : payload.value > def.value) {
            return;
        }
        payload.issues.push({
            origin: origin,
            code: "too_small",
            minimum: def.value,
            input: payload.value,
            inclusive: def.inclusive,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckMultipleOf = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMultipleOf", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        var _a;
        (_a = inst._zod.computed).multipleOf ?? (_a.multipleOf = def.value);
    });
    inst._zod.check = (payload)=>{
        if (typeof payload.value !== typeof def.value) throw new Error("Cannot mix number and bigint in multiple_of check.");
        const isMultiple = typeof payload.value === "bigint" ? payload.value % def.value === BigInt(0) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["floatSafeRemainder"])(payload.value, def.value) === 0;
        if (isMultiple) return;
        payload.issues.push({
            origin: typeof payload.value,
            code: "not_multiple_of",
            divisor: def.value,
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckNumberFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckNumberFormat", (inst, def)=>{
    $ZodCheck.init(inst, def); // no format checks
    def.format = def.format || "float64";
    const isInt = def.format?.includes("int");
    const origin = isInt ? "int" : "number";
    const [minimum, maximum] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NUMBER_FORMAT_RANGES"][def.format];
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.format = def.format;
        inst._zod.computed.minimum = minimum;
        inst._zod.computed.maximum = maximum;
        if (isInt) inst._zod.computed.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["integer"];
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        if (isInt) {
            if (!Number.isInteger(input)) {
                // invalid_type issue
                payload.issues.push({
                    expected: origin,
                    format: def.format,
                    code: "invalid_type",
                    input,
                    inst
                });
                return;
            // not_multiple_of issue
            // payload.issues.push({
            //   code: "not_multiple_of",
            //   origin: "number",
            //   input,
            //   inst,
            //   divisor: 1,
            // });
            }
            if (!Number.isSafeInteger(input)) {
                if (input > 0) {
                    // too_big
                    payload.issues.push({
                        input,
                        code: "too_big",
                        maximum: Number.MAX_SAFE_INTEGER,
                        note: "Integers must be within the the safe integer range.",
                        inst,
                        origin,
                        continue: !def.abort
                    });
                } else {
                    // too_small
                    payload.issues.push({
                        input,
                        code: "too_small",
                        minimum: Number.MIN_SAFE_INTEGER,
                        note: "Integers must be within the safe integer range.",
                        inst,
                        origin,
                        continue: !def.abort
                    });
                }
                return;
            }
        }
        if (input < minimum) {
            payload.issues.push({
                origin: "number",
                input: input,
                code: "too_small",
                minimum: minimum,
                inclusive: true,
                inst,
                continue: !def.abort
            });
        }
        if (input > maximum) {
            payload.issues.push({
                origin: "number",
                input,
                code: "too_big",
                maximum,
                inst
            });
        }
    };
});
const $ZodCheckBigIntFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckBigIntFormat", (inst, def)=>{
    $ZodCheck.init(inst, def); // no format checks
    const [minimum, maximum] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BIGINT_FORMAT_RANGES"][def.format];
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.format = def.format;
        inst._zod.computed.minimum = minimum;
        inst._zod.computed.maximum = maximum;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        if (input < minimum) {
            payload.issues.push({
                origin: "bigint",
                input,
                code: "too_small",
                minimum: minimum,
                inclusive: true,
                inst,
                continue: !def.abort
            });
        }
        if (input > maximum) {
            payload.issues.push({
                origin: "bigint",
                input,
                code: "too_big",
                maximum,
                inst
            });
        }
    };
});
const $ZodCheckMaxSize = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMaxSize", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.size !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.maximum ?? Number.POSITIVE_INFINITY;
        if (def.maximum < curr) inst._zod.computed.maximum = def.maximum;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const size = input.size;
        if (size <= def.maximum) return;
        payload.issues.push({
            origin: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSizableOrigin"])(input),
            code: "too_big",
            maximum: def.maximum,
            input,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckMinSize = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMinSize", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.size !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.minimum ?? Number.NEGATIVE_INFINITY;
        if (def.minimum > curr) inst._zod.computed.minimum = def.minimum;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const size = input.size;
        if (size >= def.minimum) return;
        payload.issues.push({
            origin: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSizableOrigin"])(input),
            code: "too_small",
            minimum: def.minimum,
            input,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckSizeEquals = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckSizeEquals", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.size !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.minimum = def.size;
        inst._zod.computed.maximum = def.size;
        inst._zod.computed.size = def.size;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const size = input.size;
        if (size === def.size) return;
        const tooBig = size > def.size;
        payload.issues.push({
            origin: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSizableOrigin"])(input),
            ...tooBig ? {
                code: "too_big",
                maximum: def.size
            } : {
                code: "too_small",
                minimum: def.size
            },
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckMaxLength = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMaxLength", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.length !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.maximum ?? Number.POSITIVE_INFINITY;
        if (def.maximum < curr) inst._zod.computed.maximum = def.maximum;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const length = input.length;
        if (length <= def.maximum) return;
        const origin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLengthableOrigin"])(input);
        payload.issues.push({
            origin,
            code: "too_big",
            maximum: def.maximum,
            input,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckMinLength = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMinLength", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.length !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        const curr = inst._zod.computed.minimum ?? Number.NEGATIVE_INFINITY;
        if (def.minimum > curr) inst._zod.computed.minimum = def.minimum;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const length = input.length;
        if (length >= def.minimum) return;
        const origin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLengthableOrigin"])(input);
        payload.issues.push({
            origin,
            code: "too_small",
            minimum: def.minimum,
            input,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckLengthEquals = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckLengthEquals", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.when = (payload)=>{
        const val = payload.value;
        return !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nullish"])(val) && val.length !== undefined;
    };
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.minimum = def.length;
        inst._zod.computed.maximum = def.length;
        inst._zod.computed.length = def.length;
    });
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const length = input.length;
        if (length === def.length) return;
        const origin = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getLengthableOrigin"])(input);
        const tooBig = length > def.length;
        payload.issues.push({
            origin,
            ...tooBig ? {
                code: "too_big",
                maximum: def.length
            } : {
                code: "too_small",
                minimum: def.length
            },
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckStringFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckStringFormat", (inst, def)=>{
    var _a;
    $ZodCheck.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.format = def.format;
        if (def.pattern) inst._zod.computed.pattern = def.pattern;
    });
    (_a = inst._zod).check ?? (_a.check = (payload)=>{
        if (!def.pattern) throw new Error("Not implemented.");
        def.pattern.lastIndex = 0;
        if (def.pattern.test(payload.value)) return;
        payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: def.format,
            input: payload.value,
            ...def.pattern ? {
                pattern: def.pattern.toString()
            } : {},
            inst,
            continue: !def.abort
        });
    });
});
const $ZodCheckRegex = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckRegex", (inst, def)=>{
    $ZodCheckStringFormat.init(inst, def);
    inst._zod.check = (payload)=>{
        def.pattern.lastIndex = 0;
        if (def.pattern.test(payload.value)) return;
        payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: "regex",
            input: payload.value,
            pattern: def.pattern.toString(),
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckLowerCase = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckLowerCase", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["lowercase"]);
    $ZodCheckStringFormat.init(inst, def);
});
const $ZodCheckUpperCase = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckUpperCase", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uppercase"]);
    $ZodCheckStringFormat.init(inst, def);
});
const $ZodCheckIncludes = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckIncludes", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const pattern = new RegExp((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(def.includes));
    def.pattern = pattern;
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.pattern = pattern;
    });
    inst._zod.check = (payload)=>{
        if (payload.value.includes(def.includes, def.position)) return;
        payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: "includes",
            includes: def.includes,
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckStartsWith = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckStartsWith", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const pattern = new RegExp(`^${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(def.prefix)}.*`);
    def.pattern ?? (def.pattern = pattern);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.pattern = pattern;
    });
    inst._zod.check = (payload)=>{
        if (payload.value.startsWith(def.prefix)) return;
        payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: "starts_with",
            prefix: def.prefix,
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
const $ZodCheckEndsWith = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckEndsWith", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const pattern = new RegExp(`.*${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(def.suffix)}$`);
    def.pattern ?? (def.pattern = pattern);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.pattern = new RegExp(`.*${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(def.suffix)}$`);
    });
    inst._zod.check = (payload)=>{
        if (payload.value.endsWith(def.suffix)) return;
        payload.issues.push({
            origin: "string",
            code: "invalid_format",
            format: "ends_with",
            suffix: def.suffix,
            input: payload.value,
            inst,
            continue: !def.abort
        });
    };
});
///////////////////////////////////
/////    $ZodCheckProperty    /////
///////////////////////////////////
function handleCheckPropertyResult(result, payload, property) {
    if (result.issues.length) {
        payload.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(property, result.issues));
    }
}
const $ZodCheckProperty = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckProperty", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.check = (payload)=>{
        const result = def.schema._zod.run({
            value: payload.value[def.property],
            issues: []
        }, {});
        if (result instanceof Promise) {
            return result.then((result)=>handleCheckPropertyResult(result, payload, def.property));
        }
        handleCheckPropertyResult(result, payload, def.property);
        return;
    };
});
const $ZodCheckMimeType = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckMimeType", (inst, def)=>{
    $ZodCheck.init(inst, def);
    const mimeSet = new Set(def.mime);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.mime = def.mime;
    });
    inst._zod.check = (payload)=>{
        if (mimeSet.has(payload.value.type)) return;
        payload.issues.push({
            code: "invalid_value",
            values: def.mime,
            input: payload.value.type,
            path: [
                "type"
            ],
            inst
        });
    };
});
const $ZodCheckOverwrite = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCheckOverwrite", (inst, def)=>{
    $ZodCheck.init(inst, def);
    inst._zod.check = (payload)=>{
        payload.value = def.tx(payload.value);
    };
});
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/doc.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "Doc": (()=>Doc)
});
class Doc {
    constructor(args = []){
        this.content = [];
        this.indent = 0;
        if (this) this.args = args;
    }
    indented(fn) {
        this.indent += 1;
        fn(this);
        this.indent -= 1;
    }
    write(arg) {
        if (typeof arg === "function") {
            arg(this, {
                execution: "sync"
            });
            arg(this, {
                execution: "async"
            });
            return;
        }
        const content = arg;
        const lines = content.split("\n").filter((x)=>x);
        const minIndent = Math.min(...lines.map((x)=>x.length - x.trimStart().length));
        const dedented = lines.map((x)=>x.slice(minIndent)).map((x)=>" ".repeat(this.indent * 2) + x);
        for (const line of dedented){
            this.content.push(line);
        }
    }
    compile() {
        const args = this?.args;
        const content = this?.content ?? [
            ``
        ];
        const lines = [
            ...content.map((x)=>`  ${x}`)
        ];
        return new Function(...args, lines.join("\n"));
    }
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/versions.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "version": (()=>version)
});
const version = {
    major: 0,
    minor: 8,
    patch: 1
};
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "$ZodAny": (()=>$ZodAny),
    "$ZodArray": (()=>$ZodArray),
    "$ZodBase64": (()=>$ZodBase64),
    "$ZodBase64URL": (()=>$ZodBase64URL),
    "$ZodBigInt": (()=>$ZodBigInt),
    "$ZodBigIntFormat": (()=>$ZodBigIntFormat),
    "$ZodBoolean": (()=>$ZodBoolean),
    "$ZodCIDRv4": (()=>$ZodCIDRv4),
    "$ZodCIDRv6": (()=>$ZodCIDRv6),
    "$ZodCUID": (()=>$ZodCUID),
    "$ZodCUID2": (()=>$ZodCUID2),
    "$ZodCatch": (()=>$ZodCatch),
    "$ZodCustom": (()=>$ZodCustom),
    "$ZodDate": (()=>$ZodDate),
    "$ZodDefault": (()=>$ZodDefault),
    "$ZodDiscriminatedUnion": (()=>$ZodDiscriminatedUnion),
    "$ZodE164": (()=>$ZodE164),
    "$ZodEmail": (()=>$ZodEmail),
    "$ZodEmoji": (()=>$ZodEmoji),
    "$ZodEnum": (()=>$ZodEnum),
    "$ZodFile": (()=>$ZodFile),
    "$ZodGUID": (()=>$ZodGUID),
    "$ZodIPv4": (()=>$ZodIPv4),
    "$ZodIPv6": (()=>$ZodIPv6),
    "$ZodISODate": (()=>$ZodISODate),
    "$ZodISODateTime": (()=>$ZodISODateTime),
    "$ZodISODuration": (()=>$ZodISODuration),
    "$ZodISOTime": (()=>$ZodISOTime),
    "$ZodInterface": (()=>$ZodInterface),
    "$ZodIntersection": (()=>$ZodIntersection),
    "$ZodJWT": (()=>$ZodJWT),
    "$ZodKSUID": (()=>$ZodKSUID),
    "$ZodLazy": (()=>$ZodLazy),
    "$ZodLiteral": (()=>$ZodLiteral),
    "$ZodMap": (()=>$ZodMap),
    "$ZodNaN": (()=>$ZodNaN),
    "$ZodNanoID": (()=>$ZodNanoID),
    "$ZodNever": (()=>$ZodNever),
    "$ZodNonOptional": (()=>$ZodNonOptional),
    "$ZodNull": (()=>$ZodNull),
    "$ZodNullable": (()=>$ZodNullable),
    "$ZodNumber": (()=>$ZodNumber),
    "$ZodNumberFormat": (()=>$ZodNumberFormat),
    "$ZodObject": (()=>$ZodObject),
    "$ZodObjectLike": (()=>$ZodObjectLike),
    "$ZodOptional": (()=>$ZodOptional),
    "$ZodPipe": (()=>$ZodPipe),
    "$ZodPromise": (()=>$ZodPromise),
    "$ZodReadonly": (()=>$ZodReadonly),
    "$ZodRecord": (()=>$ZodRecord),
    "$ZodSet": (()=>$ZodSet),
    "$ZodString": (()=>$ZodString),
    "$ZodStringFormat": (()=>$ZodStringFormat),
    "$ZodSuccess": (()=>$ZodSuccess),
    "$ZodSymbol": (()=>$ZodSymbol),
    "$ZodTemplateLiteral": (()=>$ZodTemplateLiteral),
    "$ZodTransform": (()=>$ZodTransform),
    "$ZodTuple": (()=>$ZodTuple),
    "$ZodType": (()=>$ZodType),
    "$ZodULID": (()=>$ZodULID),
    "$ZodURL": (()=>$ZodURL),
    "$ZodUUID": (()=>$ZodUUID),
    "$ZodUndefined": (()=>$ZodUndefined),
    "$ZodUnion": (()=>$ZodUnion),
    "$ZodUnknown": (()=>$ZodUnknown),
    "$ZodVoid": (()=>$ZodVoid),
    "$ZodXID": (()=>$ZodXID),
    "isValidJWT": (()=>isValidJWT)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$versions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/versions.js [app-client] (ecmascript)");
;
;
;
;
;
;
const $ZodType = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodType", (inst, def)=>{
    var _a;
    inst ?? (inst = {});
    inst._zod.id = def.type + "_" + (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomString"])(10);
    inst._zod.def = def; // set _def property
    inst._zod.computed = inst._zod.computed || {}; // initialize _computed object
    inst._zod.version = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$versions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["version"];
    const checks = [
        ...inst._zod.def.checks ?? []
    ];
    def.type;
    // if inst is itself a checks.$ZodCheck, run it as a check
    if (inst._zod.traits.has("$ZodCheck")) {
        checks.unshift(inst);
    }
    //
    for (const ch of checks){
        for (const fn of ch._zod.onattach){
            fn(inst);
        }
    }
    if (checks.length === 0) {
        // deferred initializer
        // inst._zod.parse is not yet defined
        (_a = inst._zod).deferred ?? (_a.deferred = []);
        inst._zod.deferred?.push(()=>{
            inst._zod.run = inst._zod.parse;
        });
    } else {
        const runChecks = (payload, checks, ctx)=>{
            let isAborted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aborted"])(payload);
            let asyncResult;
            for (const ch of checks){
                if (ch._zod.when) {
                    const shouldRun = ch._zod.when(payload);
                    if (!shouldRun) continue;
                } else {
                    if (isAborted) {
                        continue;
                    }
                }
                const currLen = payload.issues.length;
                const _ = ch._zod.check(payload);
                if (_ instanceof Promise && ctx?.async === false) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodAsyncError"]();
                }
                if (asyncResult || _ instanceof Promise) {
                    asyncResult = (asyncResult ?? Promise.resolve()).then(async ()=>{
                        await _;
                        const nextLen = payload.issues.length;
                        if (nextLen === currLen) return;
                        if (!isAborted) isAborted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aborted"])(payload, currLen);
                    });
                } else {
                    const nextLen = payload.issues.length;
                    if (nextLen === currLen) continue;
                    if (!isAborted) isAborted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aborted"])(payload, currLen);
                }
            }
            if (asyncResult) {
                return asyncResult.then(()=>{
                    return payload;
                });
            }
            return payload;
        };
        inst._zod.run = (payload, ctx)=>{
            const result = inst._zod.parse(payload, ctx);
            if (result instanceof Promise) {
                if (ctx.async === false) throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodAsyncError"]();
                return result.then((result)=>runChecks(result, checks, ctx));
            }
            return runChecks(result, checks, ctx);
        };
    }
    inst["~standard"] = {
        validate: (value)=>{
            const result = inst._zod.run({
                value,
                issues: []
            }, {});
            if (result instanceof Promise) {
                return result.then(({ issues, value })=>{
                    if (issues.length === 0) return {
                        value
                    };
                    return {
                        issues: issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, {}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
                    };
                });
            }
            if (result.issues.length === 0) return {
                value: result.value
            };
            return {
                issues: result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, {}, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
            };
        },
        vendor: "zod",
        version: 1
    };
});
;
const $ZodString = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodString", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = inst?._zod.computed?.pattern ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["string"])(inst._zod.computed);
    inst._zod.parse = (payload, _)=>{
        if (def.coerce) try {
            payload.value = String(payload.value);
        } catch (_) {}
        if (typeof payload.value === "string") return payload;
        payload.issues.push({
            expected: "string",
            code: "invalid_type",
            input: payload.value,
            inst
        });
        return payload;
    };
});
const $ZodStringFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodStringFormat", (inst, def)=>{
    // check initialization must come first
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckStringFormat"].init(inst, def);
    $ZodString.init(inst, def);
});
const $ZodGUID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodGUID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["guid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodUUID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodUUID", (inst, def)=>{
    if (def.version) {
        const versionMap = {
            v1: 1,
            v2: 2,
            v3: 3,
            v4: 4,
            v5: 5,
            v6: 6,
            v7: 7,
            v8: 8
        };
        const v = versionMap[def.version];
        if (v === undefined) throw new Error(`Invalid UUID version: "${def.version}"`);
        def.pattern ?? (def.pattern = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uuid"])(v));
    } else def.pattern ?? (def.pattern = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uuid"])());
    $ZodStringFormat.init(inst, def);
});
const $ZodEmail = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodEmail", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["email"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodURL = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodURL", (inst, def)=>{
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload)=>{
        try {
            const url = new URL(payload.value);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hostname"].lastIndex = 0;
            if (!__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hostname"].test(url.hostname)) throw new Error();
            return;
        } catch (_) {
            payload.issues.push({
                code: "invalid_format",
                format: "url",
                input: payload.value,
                inst
            });
        }
    };
});
const $ZodEmoji = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodEmoji", (inst, def)=>{
    def.pattern ?? (def.pattern = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["emoji"])());
    $ZodStringFormat.init(inst, def);
});
const $ZodNanoID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNanoID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["nanoid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodCUID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCUID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cuid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodCUID2 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCUID2", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cuid2"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodULID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodULID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ulid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodXID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodXID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["xid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodKSUID = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodKSUID", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ksuid"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodISODateTime = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodISODateTime", (inst, def)=>{
    def.pattern ?? (def.pattern = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["datetime"])(def));
    $ZodStringFormat.init(inst, def);
});
const $ZodISODate = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodISODate", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["date"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodISOTime = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodISOTime", (inst, def)=>{
    def.pattern ?? (def.pattern = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["time"])(def));
    $ZodStringFormat.init(inst, def);
});
const $ZodISODuration = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodISODuration", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["duration"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodIPv4 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodIPv4", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ipv4"]);
    $ZodStringFormat.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.format = `ipv4`;
    });
});
const $ZodIPv6 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodIPv6", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ipv6"]);
    $ZodStringFormat.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.format = `ipv6`;
    });
    inst._zod.check = (payload)=>{
        try {
            new URL(`http://[${payload.value}]`);
        // return;
        } catch  {
            payload.issues.push({
                code: "invalid_format",
                format: "ipv6",
                input: payload.value,
                inst
            });
        }
    };
});
const $ZodCIDRv4 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCIDRv4", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cidrv4"]);
    $ZodStringFormat.init(inst, def);
});
const $ZodCIDRv6 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCIDRv6", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cidrv6"]); // not used for validation
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload)=>{
        const [address, prefix] = payload.value.split("/");
        try {
            if (!prefix) throw new Error();
            const prefixNum = Number(prefix);
            if (`${prefixNum}` !== prefix) throw new Error();
            if (prefixNum < 0 || prefixNum > 128) throw new Error();
            new URL(`http://[${address}]`);
        } catch  {
            payload.issues.push({
                code: "invalid_format",
                format: "cidrv6",
                input: payload.value,
                inst
            });
        }
    };
});
const $ZodBase64 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodBase64", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64"]);
    $ZodStringFormat.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.contentEncoding = "base64";
    });
});
const $ZodBase64URL = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodBase64URL", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["base64url"]);
    $ZodStringFormat.init(inst, def);
    inst._zod.onattach.push((inst)=>{
        inst._zod.computed.contentEncoding = "base64url";
    });
});
const $ZodE164 = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodE164", (inst, def)=>{
    def.pattern ?? (def.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["e164"]);
    $ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
    try {
        const tokensParts = token.split(".");
        if (tokensParts.length !== 3) return false;
        const [header] = tokensParts;
        const parsedHeader = JSON.parse(atob(header));
        if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT") return false;
        if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm)) return false;
        return true;
    } catch  {
        return false;
    }
}
const $ZodJWT = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodJWT", (inst, def)=>{
    $ZodStringFormat.init(inst, def);
    inst._zod.check = (payload)=>{
        if (isValidJWT(payload.value, def.alg)) return;
        payload.issues.push({
            code: "invalid_format",
            format: "jwt",
            input: payload.value,
            inst
        });
    };
});
const $ZodNumber = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNumber", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = inst._zod.computed.pattern ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["number"];
    inst._zod.parse = (payload, _ctx)=>{
        if (def.coerce) try {
            payload.value = Number(payload.value);
        } catch (_) {}
        const input = payload.value;
        if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) {
            return payload;
        }
        const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? "Infinity" : undefined : undefined;
        payload.issues.push({
            expected: "number",
            code: "invalid_type",
            input,
            inst,
            ...received ? {
                received
            } : {}
        });
        return payload;
    };
});
const $ZodNumberFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNumber", (inst, def)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckNumberFormat"].init(inst, def);
    $ZodNumber.init(inst, def); // no format checksp
});
const $ZodBoolean = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodBoolean", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["boolean"];
    inst._zod.parse = (payload, _ctx)=>{
        if (def.coerce) try {
            payload.value = Boolean(payload.value);
        } catch (_) {}
        const input = payload.value;
        if (typeof input === "boolean") return payload;
        payload.issues.push({
            expected: "boolean",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodBigInt = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodBigInt", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["bigint"];
    inst._zod.parse = (payload, _ctx)=>{
        if (def.coerce) try {
            payload.value = BigInt(payload.value);
        } catch (_) {}
        const { value: input } = payload;
        if (typeof input === "bigint") return payload;
        payload.issues.push({
            expected: "bigint",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodBigIntFormat = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodBigInt", (inst, def)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckBigIntFormat"].init(inst, def);
    $ZodBigInt.init(inst, def); // no format checks
});
const $ZodSymbol = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodSymbol", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        const { value: input } = payload;
        if (typeof input === "symbol") return payload;
        payload.issues.push({
            expected: "symbol",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodUndefined = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodUndefined", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["undefined"];
    inst._zod.values = new Set([
        undefined
    ]);
    inst._zod.parse = (payload, _ctx)=>{
        const { value: input } = payload;
        if (typeof input === "undefined") return payload;
        payload.issues.push({
            expected: "undefined",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodNull = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNull", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.pattern = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["null"];
    inst._zod.values = new Set([
        null
    ]);
    inst._zod.parse = (payload, _ctx)=>{
        const { value: input } = payload;
        if (input === null) return payload;
        payload.issues.push({
            expected: "null",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodAny = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodAny", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload)=>payload;
});
const $ZodUnknown = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodUnknown", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload)=>payload;
});
const $ZodNever = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNever", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        payload.issues.push({
            expected: "never",
            code: "invalid_type",
            input: payload.value,
            inst
        });
        return payload;
    };
});
const $ZodVoid = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodVoid", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        const { value: input } = payload;
        if (typeof input === "undefined") return payload;
        payload.issues.push({
            expected: "void",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodDate = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodDate", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        if (def.coerce) {
            try {
                payload.value = new Date(payload.value);
            } catch (_err) {}
        }
        const input = payload.value;
        const isDate = input instanceof Date;
        const isValidDate = isDate && !Number.isNaN(input.getTime());
        if (isValidDate) return payload;
        payload.issues.push({
            expected: "date",
            code: "invalid_type",
            input,
            ...isDate ? {
                received: "Invalid Date"
            } : {},
            inst
        });
        return payload;
    };
});
function handleArrayResult(result, final, index) {
    if (result.issues.length) {
        final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(index, result.issues));
    }
    final.value[index] = result.value;
}
const $ZodArray = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodArray", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!Array.isArray(input)) {
            payload.issues.push({
                expected: "array",
                code: "invalid_type",
                input,
                inst
            });
            return payload;
        }
        payload.value = Array(input.length);
        const proms = [];
        for(let i = 0; i < input.length; i++){
            const item = input[i];
            const result = def.element._zod.run({
                value: item,
                issues: []
            }, ctx);
            if (result instanceof Promise) {
                proms.push(result.then((result)=>handleArrayResult(result, payload, i)));
            } else {
                handleArrayResult(result, payload, i);
            }
        }
        if (proms.length) {
            return Promise.all(proms).then(()=>payload);
        }
        return payload; //handleArrayResultsAsync(parseResults, final);
    };
});
function handleObjectResult(result, final, key) {
    // if(isOptional)
    if (result.issues.length) {
        final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
    } else {
        final.value[key] = result.value;
    }
}
function handleOptionalObjectResult(result, final, key, input) {
    if (result.issues.length) {
        // validation failed against value schema
        if (input[key] === undefined) {
            // if input was undefined, ignore the error
            if (key in input) {
                final.value[key] = undefined;
            }
        } else {
            final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
        }
    } else if (result.value === undefined) {
        // validation returned `undefined`
        if (key in input) final.value[key] = undefined;
    } else {
        // non-undefined value
        final.value[key] = result.value;
    }
}
const $ZodObjectLike = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodObjectLike", (inst, def)=>{
    $ZodType.init(inst, def);
    // util.defineLazy(inst._zod, "shape", () => def.shape);
    const _normalized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cached"])(()=>{
        const keys = Object.keys(def.shape);
        return {
            shape: def.shape,
            keys,
            keySet: new Set(keys),
            numKeys: keys.length,
            optionalKeys: new Set(def.optional)
        };
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "disc", ()=>{
        const shape = def.shape;
        const discMap = new Map();
        let hasDisc = false;
        for(const key in shape){
            const field = shape[key]._zod;
            if (field.values || field.disc) {
                hasDisc = true;
                const o = {
                    values: new Set(field.values ?? []),
                    maps: field.disc ? [
                        field.disc
                    ] : []
                };
                discMap.set(key, o);
            }
        }
        if (!hasDisc) return undefined;
        return discMap;
    });
    const generateFastpass = (shape)=>{
        const doc = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Doc"]([
            "shape",
            "payload",
            "ctx"
        ]);
        const { keys, optionalKeys } = _normalized.value;
        const parseStr = (key)=>{
            const k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esc"])(key);
            return `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
        };
        // doc.write(`const shape = inst._zod.def.shape;`);
        doc.write(`const input = payload.value;`);
        const ids = {};
        for (const key of keys){
            ids[key] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["randomString"])(15);
        }
        for (const key of keys){
            if (optionalKeys.has(key)) continue;
            const id = ids[key];
            doc.write(`const ${id} = ${parseStr(key)};`);
            doc.write(`
          if (${id}.issues.length) payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esc"])(key)}, ...iss.path] : [${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esc"])(key)}]
          })));`);
        }
        // check for missing keys
        // for (const key of keys) {
        //   if (optionalKeys.has(key)) continue;
        //   doc.write(`if(!(${util.esc(key)} in input)) {`);
        //   doc.indented(() => {
        //     doc.write(`payload.issues.push({`);
        //     doc.indented(() => {
        //       doc.write(`code: "invalid_type",`);
        //       doc.write(`path: [${util.esc(key)}],`);
        //       doc.write(`expected: "nonoptional",`);
        //       doc.write(`note: 'Missing required key: "${key}"',`);
        //       doc.write(`input,`);
        //       doc.write(`inst,`);
        //     });
        //     doc.write(`});`);
        //   });
        //   doc.write(`}`);
        // }
        // add required keys to result
        // doc.write(`return payload;`);
        // doc.write(`if(Object.keys(input).length === ${keys.length}) {
        //   payload.value = {...input};
        //   return payload;
        // }`);
        doc.write(`payload.value = {`);
        doc.indented(()=>{
            for (const key of keys){
                if (optionalKeys.has(key)) continue;
                const id = ids[key];
                doc.write(`  ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esc"])(key)}: ${id}.value,`);
            // doc.write(`payload.value[${util.esc(key)}] = ${id}.value;`);
            }
        });
        doc.write(`}`);
        // add in optionalKeys if defined
        // OLD: only run validation if they are define in input
        // for (const key of keys) {
        //   if (!optionalKeys.has(key)) continue;
        //   const id = ids[key];
        //   doc.write(`if (${util.esc(key)} in input) {`);
        //   doc.indented(() => {
        //     doc.write(`if(input[${util.esc(key)}] === undefined) {`);
        //     doc.indented(() => {
        //       doc.write(`payload.value[${util.esc(key)}] = undefined;`);
        //     });
        //     doc.write(`} else {`);
        //     doc.indented(() => {
        //       doc.write(`const ${id} = ${parseStr(key)};`);
        //       doc.write(`payload.value[${util.esc(key)}] = ${id}.value;`);
        //       doc.write(`
        //         if (${id}.issues.length) payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
        //           ...iss,
        //           path: iss.path ? [${util.esc(key)}, ...iss.path] : [${util.esc(key)}]
        //         })));`);
        //     });
        //     doc.write(`}`);
        //   });
        //   doc.write(`}`);
        // }
        // NEW: always run validation
        // this lets default values get applied to optionals
        for (const key of keys){
            if (!optionalKeys.has(key)) continue;
            const id = ids[key];
            doc.write(`const ${id} = ${parseStr(key)};`);
            const k = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esc"])(key);
            doc.write(`
        if (${id}.issues.length) {
          if (input[${k}] === undefined) {
            if (${k} in input) {
              payload.value[${k}] = undefined;
            }
          } else {
            payload.issues = payload.issues.concat(
              ${id}.issues.map((iss) => ({
                ...iss,
                path: iss.path ? [${k}, ...iss.path] : [${k}],
              }))
            );
          }
        } else if (${id}.value === undefined) {
          if (${k} in input) payload.value[${k}] = undefined;
        } else {
          payload.value[${k}] = ${id}.value;
        }  
        `);
        }
        // doc.write(`payload.value = final;`);
        doc.write(`return payload;`);
        // return doc.compile().bind(null, shape);
        const fn = doc.compile();
        return (payload, ctx)=>fn(shape, payload, ctx);
    // return fn.bind(null, _inst._zod.def.shape);
    };
    let fastpass;
    const fastEnabled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["allowsEval"].value; // && !def.catchall;
    const isObject = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"];
    const { catchall } = def;
    let value;
    // const noCatchall = !def.catchall;
    inst._zod.parse = (payload, ctx)=>{
        value ?? (value = _normalized.value);
        const input = payload.value;
        if (!isObject(input)) {
            payload.issues.push({
                expected: "object",
                code: "invalid_type",
                input,
                inst
            });
            return payload;
        }
        const proms = [];
        if (fastEnabled && ctx?.async === false && ctx.noPrecompilation !== true) {
            // always synchronous
            if (!fastpass) fastpass = generateFastpass(def.shape);
            payload = fastpass(payload, ctx);
        } else {
            payload.value = {};
            // const normalized = _normalized.value;
            const { keys, shape, optionalKeys } = value;
            for (const key of keys){
                const valueSchema = shape[key];
                // do not add omitted optional keys
                // if (!(key in input)) {
                //   if (optionalKeys.has(key)) continue;
                //   payload.issues.push({
                //     code: "invalid_type",
                //     path: [key],
                //     expected: "nonoptional",
                //     note: `Missing required key: "${key}"`,
                //     input,
                //     inst,
                //   });
                // }
                const r = valueSchema._zod.run({
                    value: input[key],
                    issues: []
                }, ctx);
                const isOptional = optionalKeys.has(key);
                // if (isOptional) {
                //   if (!(key in input)) {
                //     continue;
                //   }
                //   if (input[key] === undefined) {
                //     input[key] = undefined;
                //     continue;
                //   }
                // }
                // const r = valueSchema._zod.run({ value: input[key], issues: [] }, ctx);
                if (r instanceof Promise) {
                    proms.push(r.then((r)=>isOptional ? handleOptionalObjectResult(r, payload, key, input) : handleObjectResult(r, payload, key)));
                } else {
                    if (isOptional) {
                        handleOptionalObjectResult(r, payload, key, input);
                    } else {
                        handleObjectResult(r, payload, key);
                    }
                }
            }
        }
        if (!catchall) {
            // return payload;
            return proms.length ? Promise.all(proms).then(()=>payload) : payload;
        }
        const unrecognized = [];
        // iterate over input keys
        const keySet = value.keySet;
        const _catchall = catchall._zod;
        const t = _catchall.def.type;
        for (const key of Object.keys(input)){
            if (keySet.has(key)) continue;
            if (t === "never") {
                unrecognized.push(key);
                continue;
            }
            const r = _catchall.run({
                value: input[key],
                issues: []
            }, ctx);
            if (r instanceof Promise) {
                proms.push(r.then((r)=>handleObjectResult(r, payload, key)));
            } else {
                handleObjectResult(r, payload, key);
            }
        }
        if (unrecognized.length) {
            payload.issues.push({
                code: "unrecognized_keys",
                keys: unrecognized,
                input,
                inst
            });
        }
        if (!proms.length) return payload;
        return Promise.all(proms).then(()=>{
            return payload;
        });
    };
});
const $ZodInterface = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodInterface", (inst, def)=>{
    $ZodObjectLike.init(inst, def);
});
const $ZodObject = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodObject", (inst, def)=>{
    $ZodObjectLike.init(inst, def);
});
function handleUnionResults(results, final, inst, ctx) {
    for (const result of results){
        if (result.issues.length === 0) {
            final.value = result.value;
            return final;
        }
    }
    final.issues.push({
        code: "invalid_union",
        input: final.value,
        inst,
        errors: results.map((result)=>result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())))
    });
    return final;
}
const $ZodUnion = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodUnion", (inst, def)=>{
    $ZodType.init(inst, def);
    const values = new Set();
    if (def.options.every((o)=>o._zod.values)) {
        for (const option of def.options){
            for (const v of option._zod.values){
                values.add(v);
            }
        }
        inst._zod.values = values;
    }
    // computed union regex for pattern if all options have pattern
    if (def.options.every((o)=>o._zod.pattern)) {
        const patterns = def.options.map((o)=>o._zod.pattern);
        inst._zod.pattern = new RegExp(`^(${patterns.map((p)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanRegex"])(p.source)).join("|")})$`);
    }
    inst._zod.parse = (payload, ctx)=>{
        const async = false;
        const results = [];
        for (const option of def.options){
            const result = option._zod.run({
                value: payload.value,
                issues: []
            }, ctx);
            if (result instanceof Promise) {
                results.push(result);
            } else {
                if (result.issues.length === 0) return result;
                results.push(result);
            }
        }
        if ("TURBOPACK compile-time truthy", 1) return handleUnionResults(results, payload, inst, ctx);
        "TURBOPACK unreachable";
    };
});
function matchDiscriminators(input, discs) {
    let matched = true;
    for (const [key, value] of discs){
        const data = input?.[key];
        if (value.values.size && !value.values.has(data)) {
            matched = false;
        }
        if (value.maps.length > 0) {
            for (const m of value.maps){
                if (!matchDiscriminators(data, m)) {
                    matched = false;
                }
            }
        }
    }
    return matched;
}
const $ZodDiscriminatedUnion = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodDiscriminatedUnion", (inst, def)=>{
    $ZodUnion.init(inst, def);
    const _super = inst._zod.parse;
    const _disc = new Map();
    for (const el of def.options){
        if (!el._zod.disc) throw new Error(`Invalid discriminated union option at index "${def.options.indexOf(el)}"`);
        for (const [key, o] of el._zod.disc){
            if (!_disc.has(key)) _disc.set(key, {
                values: new Set(),
                maps: []
            });
            const _o = _disc.get(key);
            for (const v of o.values){
                // Removed to account for unions of unions
                // Some schemas may have the same discriminator value in this case
                _o.values.add(v);
            }
            for (const m of o.maps)_o.maps.push(m);
        }
    }
    inst._zod.disc = _disc;
    const discMap = new Map();
    for (const option of def.options){
        const disc = option._zod.disc;
        if (!disc) {
            throw new Error(`Invalid disciminated union element: ${option._zod.def.type}`);
        }
        discMap.set(option, disc);
    }
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isObject"])(input)) {
            payload.issues.push({
                code: "invalid_type",
                expected: "object",
                input,
                inst
            });
            return payload;
        }
        const filteredOptions = [];
        for (const option of def.options){
            if (discMap.has(option)) {
                if (matchDiscriminators(input, discMap.get(option))) {
                    filteredOptions.push(option);
                }
            } else {
                // no discriminator
                filteredOptions.push(option);
            }
        }
        if (filteredOptions.length === 1) return filteredOptions[0]._zod.run(payload, ctx);
        if (def.unionFallback) {
            return _super(payload, ctx);
        }
        payload.issues.push({
            code: "invalid_union",
            errors: [],
            note: "No matching discriminator",
            input,
            inst
        });
        return payload;
    };
});
const $ZodIntersection = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodIntersection", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const { value: input } = payload;
        const left = def.left._zod.run({
            value: input,
            issues: []
        }, ctx);
        const right = def.right._zod.run({
            value: input,
            issues: []
        }, ctx);
        const async = left instanceof Promise || right instanceof Promise;
        if (async) {
            return Promise.all([
                left,
                right
            ]).then(([left, right])=>{
                return handleIntersectionResults(payload, left, right);
            });
        }
        return handleIntersectionResults(payload, left, right);
    };
});
function mergeValues(a, b) {
    // const aType = parse.t(a);
    // const bType = parse.t(b);
    if (a === b) {
        return {
            valid: true,
            data: a
        };
    }
    if (a instanceof Date && b instanceof Date && +a === +b) {
        return {
            valid: true,
            data: a
        };
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(a) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(b)) {
        const bKeys = Object.keys(b);
        const sharedKeys = Object.keys(a).filter((key)=>bKeys.indexOf(key) !== -1);
        const newObj = {
            ...a,
            ...b
        };
        for (const key of sharedKeys){
            const sharedValue = mergeValues(a[key], b[key]);
            if (!sharedValue.valid) {
                return {
                    valid: false,
                    mergeErrorPath: [
                        key,
                        ...sharedValue.mergeErrorPath
                    ]
                };
            }
            newObj[key] = sharedValue.data;
        }
        return {
            valid: true,
            data: newObj
        };
    }
    if (Array.isArray(a) && Array.isArray(b)) {
        if (a.length !== b.length) {
            return {
                valid: false,
                mergeErrorPath: []
            };
        }
        const newArray = [];
        for(let index = 0; index < a.length; index++){
            const itemA = a[index];
            const itemB = b[index];
            const sharedValue = mergeValues(itemA, itemB);
            if (!sharedValue.valid) {
                return {
                    valid: false,
                    mergeErrorPath: [
                        index,
                        ...sharedValue.mergeErrorPath
                    ]
                };
            }
            newArray.push(sharedValue.data);
        }
        return {
            valid: true,
            data: newArray
        };
    }
    return {
        valid: false,
        mergeErrorPath: []
    };
}
function handleIntersectionResults(result, left, right) {
    if (left.issues.length) {
        result.issues.push(...left.issues);
    }
    if (right.issues.length) {
        result.issues.push(...right.issues);
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aborted"])(result)) return result;
    const merged = mergeValues(left.value, right.value);
    if (!merged.valid) {
        throw new Error(`Unmergable intersection. Error path: ` + `${JSON.stringify(merged.mergeErrorPath)}`);
    }
    result.value = merged.data;
    return result;
}
const $ZodTuple = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodTuple", (inst, def)=>{
    $ZodType.init(inst, def);
    const items = def.items;
    const optStart = items.length - [
        ...items
    ].reverse().findIndex((item)=>item._zod.qout !== "true");
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!Array.isArray(input)) {
            payload.issues.push({
                input,
                inst,
                expected: "tuple",
                code: "invalid_type"
            });
            return payload;
        }
        payload.value = [];
        const proms = [];
        if (!def.rest) {
            const tooBig = input.length > items.length;
            const tooSmall = input.length < optStart - 1;
            if (tooBig || tooSmall) {
                payload.issues.push({
                    input,
                    inst,
                    origin: "array",
                    ...tooBig ? {
                        code: "too_big",
                        maximum: items.length
                    } : {
                        code: "too_small",
                        minimum: items.length
                    }
                });
                return payload;
            }
        }
        let i = -1;
        for (const item of items){
            i++;
            if (i >= input.length) {
                if (i >= optStart) continue;
            }
            const result = item._zod.run({
                value: input[i],
                issues: []
            }, ctx);
            if (result instanceof Promise) {
                proms.push(result.then((result)=>handleTupleResult(result, payload, i)));
            } else {
                handleTupleResult(result, payload, i);
            }
        }
        if (def.rest) {
            const rest = input.slice(items.length);
            for (const el of rest){
                i++;
                const result = def.rest._zod.run({
                    value: el,
                    issues: []
                }, ctx);
                if (result instanceof Promise) {
                    proms.push(result.then((result)=>handleTupleResult(result, payload, i)));
                } else {
                    handleTupleResult(result, payload, i);
                }
            }
        }
        if (proms.length) return Promise.all(proms).then(()=>payload);
        return payload;
    };
});
function handleTupleResult(result, final, index) {
    if (result.issues.length) {
        final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(index, result.issues));
    } else {
        final.value[index] = result.value;
    }
}
const $ZodRecord = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodRecord", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isPlainObject"])(input)) {
            payload.issues.push({
                expected: "record",
                code: "invalid_type",
                input,
                inst
            });
            return payload;
        }
        const proms = [];
        if (def.keyType._zod.values) {
            const values = def.keyType._zod.values;
            payload.value = {};
            for (const key of values){
                if (typeof key === "string" || typeof key === "number" || typeof key === "symbol") {
                    const result = def.valueType._zod.run({
                        value: input[key],
                        issues: []
                    }, ctx);
                    if (result instanceof Promise) {
                        proms.push(result.then((result)=>{
                            if (result.issues.length) {
                                payload.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
                            }
                            payload.value[key] = result.value;
                        }));
                    } else {
                        if (result.issues.length) {
                            payload.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
                        }
                        payload.value[key] = result.value;
                    }
                }
            }
            let unrecognized;
            for(const key in input){
                if (!values.has(key)) {
                    unrecognized = unrecognized ?? [];
                    unrecognized.push(key);
                }
            }
            if (unrecognized && unrecognized.length > 0) {
                payload.issues.push({
                    code: "unrecognized_keys",
                    input,
                    inst,
                    keys: unrecognized
                });
            }
        } else {
            payload.value = {};
            for (const key of Reflect.ownKeys(input)){
                if (key === "__proto__") continue;
                const keyResult = def.keyType._zod.run({
                    value: key,
                    issues: []
                }, ctx);
                if (keyResult instanceof Promise) {
                    throw new Error("Async schemas not supported in object keys currently");
                }
                if (keyResult.issues.length) {
                    payload.issues.push({
                        origin: "record",
                        code: "invalid_key",
                        issues: keyResult.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])())),
                        input: key,
                        path: [
                            key
                        ],
                        inst
                    });
                    continue;
                }
                const result = def.valueType._zod.run({
                    value: input[key],
                    issues: []
                }, ctx);
                if (result instanceof Promise) {
                    proms.push(result.then((result)=>{
                        if (result.issues.length) {
                            payload.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
                        } else {
                            payload.value[keyResult.value] = result.value;
                        }
                    }));
                } else {
                    if (result.issues.length) {
                        payload.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, result.issues));
                    } else {
                        payload.value[keyResult.value] = result.value;
                    }
                }
            }
        }
        if (proms.length) {
            return Promise.all(proms).then(()=>payload);
        }
        return payload;
    };
});
const $ZodMap = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodMap", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!(input instanceof Map)) {
            payload.issues.push({
                expected: "map",
                code: "invalid_type",
                input,
                inst
            });
            return payload;
        }
        const proms = [];
        payload.value = new Map();
        for (const [key, value] of input){
            const keyResult = def.keyType._zod.run({
                value: key,
                issues: []
            }, ctx);
            const valueResult = def.valueType._zod.run({
                value: value,
                issues: []
            }, ctx);
            if (keyResult instanceof Promise || valueResult instanceof Promise) {
                proms.push(Promise.all([
                    keyResult,
                    valueResult
                ]).then(([keyResult, valueResult])=>{
                    handleMapResult(keyResult, valueResult, payload, key, input, inst, ctx);
                }));
            } else {
                handleMapResult(keyResult, valueResult, payload, key, input, inst, ctx);
            }
        }
        if (proms.length) return Promise.all(proms).then(()=>payload);
        return payload;
    };
});
function handleMapResult(keyResult, valueResult, final, key, input, inst, ctx) {
    if (keyResult.issues.length) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propertyKeyTypes"].has(typeof key)) {
            final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, keyResult.issues));
        } else {
            final.issues.push({
                origin: "map",
                code: "invalid_key",
                input,
                inst,
                issues: keyResult.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
            });
        }
    }
    if (valueResult.issues.length) {
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propertyKeyTypes"].has(typeof key)) {
            final.issues.push(...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["prefixIssues"])(key, valueResult.issues));
        } else {
            final.issues.push({
                origin: "map",
                code: "invalid_element",
                input,
                inst,
                key: key,
                issues: valueResult.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
            });
        }
    } else {
        final.value.set(keyResult.value, valueResult.value);
    }
}
const $ZodSet = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodSet", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const input = payload.value;
        if (!(input instanceof Set)) {
            payload.issues.push({
                input,
                inst,
                expected: "set",
                code: "invalid_type"
            });
            return payload;
        }
        const proms = [];
        payload.value = new Set();
        for (const item of input){
            const result = def.valueType._zod.run({
                value: item,
                issues: []
            }, ctx);
            if (result instanceof Promise) {
                proms.push(result.then((result)=>handleSetResult(result, payload)));
            } else handleSetResult(result, payload);
        }
        if (proms.length) return Promise.all(proms).then(()=>payload);
        return payload;
    };
});
function handleSetResult(result, final) {
    if (result.issues.length) {
        final.issues.push(...result.issues);
    } else {
        final.value.add(result.value);
    }
}
const $ZodEnum = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodEnum", (inst, def)=>{
    $ZodType.init(inst, def);
    const values = Object.entries(def.entries)// remove reverse mappings
    .filter(([k, _])=>{
        return typeof def.entries[def.entries[k]] !== "number";
    }).map(([_, v])=>v);
    inst._zod.values = new Set(values);
    inst._zod.pattern = new RegExp(`^(${values.filter((k)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["propertyKeyTypes"].has(typeof k)).map((o)=>typeof o === "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(o) : o.toString()).join("|")})$`);
    inst._zod.parse = (payload, _ctx)=>{
        const input = payload.value;
        if (inst._zod.values.has(input)) {
            return payload;
        }
        payload.issues.push({
            code: "invalid_value",
            values,
            input,
            inst
        });
        return payload;
    };
});
const $ZodLiteral = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodLiteral", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.values = new Set(def.values);
    inst._zod.pattern = new RegExp(`^(${def.values.map((o)=>typeof o === "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(o) : o ? o.toString() : String(o)).join("|")})$`);
    inst._zod.parse = (payload, _ctx)=>{
        const input = payload.value;
        if (inst._zod.values.has(input)) {
            return payload;
        }
        payload.issues.push({
            code: "invalid_value",
            values: def.values,
            input,
            inst
        });
        return payload;
    };
});
const $ZodFile = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodFile", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        const input = payload.value;
        if (input instanceof File) return payload;
        payload.issues.push({
            expected: "file",
            code: "invalid_type",
            input,
            inst
        });
        return payload;
    };
});
const $ZodTransform = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodTransform", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        const _out = def.transform(payload.value, payload);
        if (_ctx.async) {
            const output = _out instanceof Promise ? _out : Promise.resolve(_out);
            return output.then((output)=>{
                payload.value = output;
                return payload;
            });
        }
        if (_out instanceof Promise) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodAsyncError"]();
        }
        payload.value = _out;
        return payload;
    };
});
const $ZodOptional = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodOptional", (inst, def)=>{
    $ZodType.init(inst, def);
    // inst._zod.qin = "true";
    inst._zod.qout = "true";
    if (def.innerType._zod.values) inst._zod.values = new Set([
        ...def.innerType._zod.values,
        undefined
    ]);
    const pattern = def.innerType._zod.pattern;
    if (pattern) inst._zod.pattern = new RegExp(`^(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanRegex"])(pattern.source)})?$`);
    inst._zod.parse = (payload, ctx)=>{
        if (payload.value === undefined) {
            return payload;
        }
        return def.innerType._zod.run(payload, ctx);
    };
});
const $ZodNullable = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNullable", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.qin = def.innerType._zod.qin;
    inst._zod.qout = def.innerType._zod.qout;
    const pattern = def.innerType._zod.pattern;
    if (pattern) inst._zod.pattern = new RegExp(`^(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanRegex"])(pattern.source)}|null)$`);
    if (def.innerType._zod.values) inst._zod.values = new Set([
        ...def.innerType._zod.values,
        null
    ]);
    inst._zod.parse = (payload, ctx)=>{
        if (payload.value === null) return payload;
        return def.innerType._zod.run(payload, ctx);
    };
});
const $ZodDefault = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodDefault", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.values = def.innerType._zod.values;
    inst._zod.parse = (payload, ctx)=>{
        if (payload.value === undefined) {
            payload.value = def.defaultValue();
            /**
             * $ZodDefault always returns the default value immediately.
             * It doesn't pass the default value into the validator ("prefault"). There's no reason to pass the default value through validation. The validity of the default is enforced by TypeScript statically. Otherwise, it's the responsibility of the user to ensure the default is valid. In the case of pipes with divergent in/out types, you can specify the default on the `in` schema of your ZodPipe to set a "prefault" for the pipe.   */ return payload;
        }
        const result = def.innerType._zod.run(payload, ctx);
        if (result instanceof Promise) {
            return result.then((result)=>handleDefaultResult(result, def));
        }
        return handleDefaultResult(result, def);
    };
});
function handleDefaultResult(payload, def) {
    if (payload.value === undefined) {
        payload.value = def.defaultValue();
    }
    return payload;
}
const $ZodNonOptional = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNonOptional", (inst, def)=>{
    $ZodType.init(inst, def);
    if (def.innerType._zod.values) inst._zod.values = new Set([
        ...def.innerType._zod.values
    ].filter((x)=>x !== undefined));
    inst._zod.parse = (payload, ctx)=>{
        const result = def.innerType._zod.run(payload, ctx);
        if (result instanceof Promise) {
            return result.then((result)=>handleNonOptionalResult(result, inst));
        }
        return handleNonOptionalResult(result, inst);
    };
});
function handleNonOptionalResult(payload, inst) {
    if (!payload.issues.length && payload.value === undefined) {
        payload.issues.push({
            code: "invalid_type",
            expected: "nonoptional",
            input: payload.value,
            inst
        });
    }
    return payload;
}
const $ZodSuccess = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodSuccess", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        const result = def.innerType._zod.run(payload, ctx);
        if (result instanceof Promise) {
            return result.then((result)=>{
                payload.value = result.issues.length === 0;
                return payload;
            });
        }
        payload.value = result.issues.length === 0;
        return payload;
    };
});
const $ZodCatch = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCatch", (inst, def)=>{
    $ZodType.init(inst, def);
    // inst._zod.qin = def.innerType._zod.qin;
    inst._zod.qout = def.innerType._zod.qout;
    inst._zod.values = def.innerType._zod.values;
    inst._zod.parse = (payload, ctx)=>{
        const result = def.innerType._zod.run(payload, ctx);
        if (result instanceof Promise) {
            return result.then((result)=>{
                if (result.issues.length) {
                    payload.value = def.catchValue({
                        ...payload,
                        error: {
                            issues: result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
                        },
                        input: payload.value
                    });
                    payload.issues = [];
                } else {
                    payload.value = result.value;
                }
                return payload;
            });
        }
        if (result.issues.length) {
            payload.value = def.catchValue({
                ...payload,
                error: {
                    issues: result.issues.map((iss)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["finalizeIssue"])(iss, ctx, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"])()))
                },
                input: payload.value
            });
            payload.issues = [];
        } else {
            payload.value = result.value;
        }
        return payload;
    };
});
const $ZodNaN = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodNaN", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _ctx)=>{
        if (typeof payload.value !== "number" || !Number.isNaN(payload.value)) {
            payload.issues.push({
                input: payload.value,
                inst,
                expected: "nan",
                code: "invalid_type"
            });
            return payload;
        }
        return payload;
    };
});
const $ZodPipe = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodPipe", (inst, def)=>{
    $ZodType.init(inst, def);
    // inst._zod.qin = def.in._zod.qin;
    // inst._zod.qout = def.in._zod.qout;
    inst._zod.values = def.in._zod.values;
    inst._zod.parse = (payload, ctx)=>{
        const left = def.in._zod.run(payload, ctx);
        if (left instanceof Promise) {
            return left.then((left)=>handlePipeResult(left, def, ctx));
        }
        return handlePipeResult(left, def, ctx);
    };
});
function handlePipeResult(left, def, ctx) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["aborted"])(left)) {
        return left;
    }
    return def.out._zod.run({
        value: left.value,
        issues: left.issues
    }, ctx);
}
const $ZodReadonly = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodReadonly", (inst, def)=>{
    $ZodType.init(inst, def);
    // inst._zod.qin = def.innerType._zod.qin;
    inst._zod.qout = def.innerType._zod.qout;
    inst._zod.parse = (payload, ctx)=>{
        const result = def.innerType._zod.run(payload, ctx);
        if (result instanceof Promise) {
            return result.then(handleReadonlyResult);
        }
        return handleReadonlyResult(result);
    };
});
function handleReadonlyResult(payload) {
    payload.value = Object.freeze(payload.value);
    return payload;
}
const $ZodTemplateLiteral = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodTemplateLiteral", (inst, def)=>{
    $ZodType.init(inst, def);
    const regexParts = [];
    for (const part of def.parts){
        if (part instanceof $ZodType) {
            if (!part._zod.pattern) {
                // if (!source)
                throw new Error(`Invalid template literal part, no pattern found: ${[
                    ...part._zod.traits
                ].shift()}`);
            }
            const source = part._zod.pattern instanceof RegExp ? part._zod.pattern.source : part._zod.pattern;
            if (!source) throw new Error(`Invalid template literal part: ${part._zod.traits}`);
            const start = source.startsWith("^") ? 1 : 0;
            const end = source.endsWith("$") ? source.length - 1 : source.length;
            regexParts.push(source.slice(start, end));
        } else if (part === null || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["primitiveTypes"].has(typeof part)) {
            regexParts.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["escapeRegex"])(`${part}`));
        } else {
            throw new Error(`Invalid template literal part: ${part}`);
        }
    }
    inst._zod.pattern = new RegExp(`^${regexParts.join("")}$`);
    inst._zod.parse = (payload, _ctx)=>{
        if (typeof payload.value !== "string") {
            payload.issues.push({
                input: payload.value,
                inst,
                expected: "template_literal",
                code: "invalid_type"
            });
            return payload;
        }
        inst._zod.pattern.lastIndex = 0;
        if (!inst._zod.pattern.test(payload.value)) {
            payload.issues.push({
                input: payload.value,
                inst,
                code: "invalid_format",
                format: "template_literal",
                pattern: inst._zod.pattern.source
            });
            return payload;
        }
        return payload;
    };
});
const $ZodPromise = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodPromise", (inst, def)=>{
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, ctx)=>{
        return Promise.resolve(payload.value).then((inner)=>def.innerType._zod.run({
                value: inner,
                issues: []
            }, ctx));
    };
});
const $ZodLazy = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodLazy", (inst, def)=>{
    $ZodType.init(inst, def);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "_getter", def.getter);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "pattern", ()=>inst._zod._getter._zod.pattern);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "disc", ()=>inst._zod._getter._zod.disc);
    inst._zod.parse = (payload, ctx)=>{
        return inst._zod._getter._zod.run(payload, ctx);
    };
    // qin and qout
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "qin", ()=>inst._zod._getter._zod.qin);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["defineLazy"])(inst._zod, "qout", ()=>inst._zod._getter._zod.qout);
});
const $ZodCustom = /*@__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$constructor"])("$ZodCustom", (inst, def)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheck"].init(inst, def);
    $ZodType.init(inst, def);
    inst._zod.parse = (payload, _)=>{
        return payload;
    };
    inst._zod.check = (payload)=>{
        const input = payload.value;
        const r = def.fn(input);
        if (r instanceof Promise) {
            return r.then((r)=>handleRefineResult(r, payload, input, inst));
        }
        handleRefineResult(r, payload, input, inst);
        return;
    };
});
function handleRefineResult(result, payload, input, inst) {
    if (!result) {
        const _iss = {
            code: "custom",
            input,
            inst,
            path: inst._zod.def.path,
            continue: !inst._zod.def.abort
        };
        if (inst._zod.def.params) _iss.params = inst._zod.def.params;
        payload.issues.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["issue"])(_iss));
    }
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$versions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/versions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/az.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "error": (()=>error),
    "parsedType": (()=>parsedType)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
const Sizable = {
    string: {
        unit: "simvol",
        verb: "olmalıdır"
    },
    file: {
        unit: "bayt",
        verb: "olmalıdır"
    },
    array: {
        unit: "element",
        verb: "olmalıdır"
    },
    set: {
        unit: "element",
        verb: "olmalıdır"
    }
};
function getSizing(origin) {
    return Sizable[origin] ?? null;
}
const parsedType = (data)=>{
    const t = typeof data;
    switch(t){
        case "number":
            {
                return Number.isNaN(data) ? "NaN" : "number";
            }
        case "object":
            {
                if (Array.isArray(data)) {
                    return "array";
                }
                if (data === null) {
                    return "null";
                }
                if (Object.getPrototypeOf(data) !== Object.prototype && data.constructor) {
                    return data.constructor.name;
                }
            }
    }
    return t;
};
const Nouns = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
};
const error = (issue)=>{
    switch(issue.code){
        case "invalid_type":
            return `Yanlış dəyər: gözlənilən ${issue.expected}, daxil olan ${parsedType(issue.input)}`;
        case "invalid_value":
            if (issue.values.length === 1) return `Yanlış dəyər: gözlənilən ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringifyPrimitive"])(issue.values[0])}`;
            return `Yanlış seçim: aşağıdakılardan biri olmalıdır: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.values, "|")}`;
        case "too_big":
            {
                const adj = issue.inclusive ? "<=" : "<";
                const sizing = getSizing(issue.origin);
                if (sizing) return `Çox böyük: gözlənilən ${issue.origin ?? "dəyər"} ${adj}${issue.maximum.toString()} ${sizing.unit ?? "element"}`;
                return `Çox böyük: gözlənilən ${issue.origin ?? "dəyər"} ${adj}${issue.maximum.toString()}`;
            }
        case "too_small":
            {
                const adj = issue.inclusive ? ">=" : ">";
                const sizing = getSizing(issue.origin);
                if (sizing) return `Çox kiçik: gözlənilən ${issue.origin} ${adj}${issue.minimum.toString()} ${sizing.unit}`;
                return `Çox kiçik: gözlənilən ${issue.origin} ${adj}${issue.minimum.toString()}`;
            }
        case "invalid_format":
            {
                const _issue = issue;
                if (_issue.format === "starts_with") return `Yanlış mətn: "${_issue.prefix}" ilə başlamalıdır`;
                if (_issue.format === "ends_with") return `Yanlış mətn: "${_issue.suffix}" ilə bitməlidir`;
                if (_issue.format === "includes") return `Yanlış mətn: "${_issue.includes}" daxil olmalıdır`;
                if (_issue.format === "regex") return `Yanlış mətn: ${_issue.pattern} şablonuna uyğun olmalıdır`;
                return `Yanlış ${Nouns[_issue.format] ?? issue.format}`;
            }
        case "not_multiple_of":
            return `Yanlış ədəd: ${issue.divisor} ilə bölünə bilən olmalıdır`;
        case "unrecognized_keys":
            return `Tanınmayan açar${issue.keys.length > 1 ? "lar" : ""}: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.keys, ", ")}`;
        case "invalid_key":
            return `${issue.origin} daxilində yanlış açar`;
        case "invalid_union":
            return "Yanlış dəyər";
        case "invalid_element":
            return `${issue.origin} daxilində yanlış dəyər`;
        default:
            return `Yanlış dəyər`;
    }
};
;
function __TURBOPACK__default__export__() {
    return {
        localeError: error
    };
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/en.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "error": (()=>error),
    "parsedType": (()=>parsedType)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
const Sizable = {
    string: {
        unit: "characters",
        verb: "to have"
    },
    file: {
        unit: "bytes",
        verb: "to have"
    },
    array: {
        unit: "items",
        verb: "to have"
    },
    set: {
        unit: "items",
        verb: "to have"
    }
};
function getSizing(origin) {
    return Sizable[origin] ?? null;
}
const parsedType = (data)=>{
    const t = typeof data;
    switch(t){
        case "number":
            {
                return Number.isNaN(data) ? "NaN" : "number";
            }
        case "object":
            {
                if (Array.isArray(data)) {
                    return "array";
                }
                if (data === null) {
                    return "null";
                }
                if (Object.getPrototypeOf(data) !== Object.prototype && data.constructor) {
                    return data.constructor.name;
                }
            }
    }
    return t;
};
const Nouns = {
    regex: "input",
    email: "email address",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "ISO datetime",
    date: "ISO date",
    time: "ISO time",
    duration: "ISO duration",
    ipv4: "IPv4 address",
    ipv6: "IPv6 address",
    cidrv4: "IPv4 range",
    cidrv6: "IPv6 range",
    base64: "base64-encoded string",
    base64url: "base64url-encoded string",
    json_string: "JSON string",
    e164: "E.164 number",
    jwt: "JWT",
    template_literal: "input"
};
const error = (issue)=>{
    switch(issue.code){
        case "invalid_type":
            return `Invalid input: expected ${issue.expected}, received ${parsedType(issue.input)}`;
        // return `Invalid input: expected ${issue.expected}, received ${util.getParsedType(issue.input)}`;
        case "invalid_value":
            if (issue.values.length === 1) return `Invalid input: expected ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringifyPrimitive"])(issue.values[0])}`;
            return `Invalid option: expected one of ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.values, "|")}`;
        case "too_big":
            {
                const adj = issue.inclusive ? "<=" : "<";
                const sizing = getSizing(issue.origin);
                if (sizing) return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
                return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
            }
        case "too_small":
            {
                const adj = issue.inclusive ? ">=" : ">";
                const sizing = getSizing(issue.origin);
                if (sizing) {
                    return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
                }
                return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
            }
        case "invalid_format":
            {
                const _issue = issue;
                if (_issue.format === "starts_with") {
                    return `Invalid string: must start with "${_issue.prefix}"`;
                }
                if (_issue.format === "ends_with") return `Invalid string: must end with "${_issue.suffix}"`;
                if (_issue.format === "includes") return `Invalid string: must include "${_issue.includes}"`;
                if (_issue.format === "regex") return `Invalid string: must match pattern ${_issue.pattern}`;
                return `Invalid ${Nouns[_issue.format] ?? issue.format}`;
            }
        case "not_multiple_of":
            return `Invalid number: must be a multiple of ${issue.divisor}`;
        case "unrecognized_keys":
            return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.keys, ", ")}`;
        case "invalid_key":
            return `Invalid key in ${issue.origin}`;
        case "invalid_union":
            return "Invalid input";
        case "invalid_element":
            return `Invalid value in ${issue.origin}`;
        default:
            return `Invalid input`;
    }
};
;
function __TURBOPACK__default__export__() {
    return {
        localeError: error
    };
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/es.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__),
    "error": (()=>error),
    "parsedType": (()=>parsedType)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
const Sizable = {
    string: {
        unit: "caracteres",
        verb: "tener"
    },
    file: {
        unit: "bytes",
        verb: "tener"
    },
    array: {
        unit: "elementos",
        verb: "tener"
    },
    set: {
        unit: "elementos",
        verb: "tener"
    }
};
function getSizing(origin) {
    return Sizable[origin] ?? null;
}
const parsedType = (data)=>{
    const t = typeof data;
    switch(t){
        case "number":
            {
                return Number.isNaN(data) ? "NaN" : "número";
            }
        case "object":
            {
                if (Array.isArray(data)) {
                    return "arreglo";
                }
                if (data === null) {
                    return "nulo";
                }
                if (Object.getPrototypeOf(data) !== Object.prototype) {
                    return data.constructor.name;
                }
            }
    }
    return t;
};
const Nouns = {
    regex: "entrada",
    email: "dirección de correo electrónico",
    url: "URL",
    emoji: "emoji",
    uuid: "UUID",
    uuidv4: "UUIDv4",
    uuidv6: "UUIDv6",
    nanoid: "nanoid",
    guid: "GUID",
    cuid: "cuid",
    cuid2: "cuid2",
    ulid: "ULID",
    xid: "XID",
    ksuid: "KSUID",
    datetime: "fecha y hora ISO",
    date: "fecha ISO",
    time: "hora ISO",
    duration: "duración ISO",
    ipv4: "dirección IPv4",
    ipv6: "dirección IPv6",
    cidrv4: "rango IPv4",
    cidrv6: "rango IPv6",
    base64: "cadena codificada en base64",
    base64url: "URL codificada en base64",
    json_string: "cadena JSON",
    e164: "número E.164",
    jwt: "JWT",
    template_literal: "entrada"
};
const error = (issue)=>{
    switch(issue.code){
        case "invalid_type":
            return `Entrada inválida: se esperaba ${issue.expected}, recibido ${parsedType(issue.input)}`;
        // return `Entrada inválida: se esperaba ${issue.expected}, recibido ${util.getParsedType(issue.input)}`;
        case "invalid_value":
            if (issue.values.length === 1) return `Entrada inválida: se esperaba ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stringifyPrimitive"])(issue.values[0])}`;
            return `Opción inválida: se esperaba una de ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.values, "|")}`;
        case "too_big":
            {
                const adj = issue.inclusive ? "<=" : "<";
                const sizing = getSizing(issue.origin);
                if (sizing) return `Demasiado grande: se esperaba que ${issue.origin ?? "valor"} tuviera ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elementos"}`;
                return `Demasiado grande: se esperaba que ${issue.origin ?? "valor"} fuera ${adj}${issue.maximum.toString()}`;
            }
        case "too_small":
            {
                const adj = issue.inclusive ? ">=" : ">";
                const sizing = getSizing(issue.origin);
                if (sizing) {
                    return `Demasiado pequeño: se esperaba que ${issue.origin} tuviera ${adj}${issue.minimum.toString()} ${sizing.unit}`;
                }
                return `Demasiado pequeño: se esperaba que ${issue.origin} fuera ${adj}${issue.minimum.toString()}`;
            }
        case "invalid_format":
            {
                const _issue = issue;
                if (_issue.format === "starts_with") return `Cadena inválida: debe comenzar con "${_issue.prefix}"`;
                if (_issue.format === "ends_with") return `Cadena inválida: debe terminar en "${_issue.suffix}"`;
                if (_issue.format === "includes") return `Cadena inválida: debe incluir "${_issue.includes}"`;
                if (_issue.format === "regex") return `Cadena inválida: debe coincidir con el patrón ${_issue.pattern}`;
                return `Inválido ${Nouns[_issue.format] ?? issue.format}`;
            }
        case "not_multiple_of":
            return `Número inválido: debe ser múltiplo de ${issue.divisor}`;
        case "unrecognized_keys":
            return `Llave${issue.keys.length > 1 ? "s" : ""} desconocida${issue.keys.length > 1 ? "s" : ""}: ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["joinValues"])(issue.keys, ", ")}`;
        case "invalid_key":
            return `Llave inválida en ${issue.origin}`;
        case "invalid_union":
            return "Entrada inválida";
        case "invalid_element":
            return `Valor inválido en ${issue.origin}`;
        default:
            return `Entrada inválida`;
    }
};
;
function __TURBOPACK__default__export__() {
    return {
        localeError: error
    };
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$az$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/az.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$en$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/en.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/es.js [app-client] (ecmascript)");
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$az$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/az.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$en$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/en.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2f$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales/es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/registries.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "$ZodJSONSchemaRegistry": (()=>$ZodJSONSchemaRegistry),
    "$ZodRegistry": (()=>$ZodRegistry),
    "$input": (()=>$input),
    "$output": (()=>$output),
    "globalRegistry": (()=>globalRegistry),
    "jsonSchemaRegistry": (()=>jsonSchemaRegistry),
    "registry": (()=>registry)
});
const $output = Symbol("ZodOutput");
const $input = Symbol("ZodInput");
class $ZodRegistry {
    constructor(){
        this._map = new WeakMap();
        this._idmap = new Map();
    }
    add(schema, ..._meta) {
        const meta = _meta[0];
        this._map.set(schema, meta);
        if (meta && typeof meta === "object" && "id" in meta) {
            if (this._idmap.has(meta.id)) {
                throw new Error(`ID ${meta.id} already exists in the registry`);
            }
            this._idmap.set(meta.id, schema);
        }
        return this;
    }
    remove(schema) {
        this._map.delete(schema);
        return this;
    }
    get(schema) {
        return this._map.get(schema);
    }
    has(schema) {
        return this._map.has(schema);
    }
}
class $ZodJSONSchemaRegistry extends $ZodRegistry {
    toJSONSchema(_schema) {
        return {};
    }
}
const globalRegistry = /*@__PURE__*/ new $ZodJSONSchemaRegistry();
function registry() {
    return new $ZodRegistry();
}
function jsonSchemaRegistry() {
    return new $ZodJSONSchemaRegistry();
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/api.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "_any": (()=>_any),
    "_array": (()=>_array),
    "_base64": (()=>_base64),
    "_base64url": (()=>_base64url),
    "_bigint": (()=>_bigint),
    "_boolean": (()=>_boolean),
    "_catch": (()=>_catch),
    "_cidrv4": (()=>_cidrv4),
    "_cidrv6": (()=>_cidrv6),
    "_coercedBigint": (()=>_coercedBigint),
    "_coercedBoolean": (()=>_coercedBoolean),
    "_coercedDate": (()=>_coercedDate),
    "_coercedNumber": (()=>_coercedNumber),
    "_coercedString": (()=>_coercedString),
    "_cuid": (()=>_cuid),
    "_cuid2": (()=>_cuid2),
    "_custom": (()=>_custom),
    "_date": (()=>_date),
    "_default": (()=>_default),
    "_discriminatedUnion": (()=>_discriminatedUnion),
    "_e164": (()=>_e164),
    "_email": (()=>_email),
    "_emoji": (()=>_emoji),
    "_endsWith": (()=>_endsWith),
    "_enum": (()=>_enum),
    "_file": (()=>_file),
    "_float32": (()=>_float32),
    "_float64": (()=>_float64),
    "_gt": (()=>_gt),
    "_gte": (()=>_gte),
    "_guid": (()=>_guid),
    "_includes": (()=>_includes),
    "_int": (()=>_int),
    "_int32": (()=>_int32),
    "_int64": (()=>_int64),
    "_interface": (()=>_interface),
    "_intersection": (()=>_intersection),
    "_ipv4": (()=>_ipv4),
    "_ipv6": (()=>_ipv6),
    "_isoDate": (()=>_isoDate),
    "_isoDateTime": (()=>_isoDateTime),
    "_isoDuration": (()=>_isoDuration),
    "_isoTime": (()=>_isoTime),
    "_jwt": (()=>_jwt),
    "_ksuid": (()=>_ksuid),
    "_lazy": (()=>_lazy),
    "_length": (()=>_length),
    "_literal": (()=>_literal),
    "_looseInterface": (()=>_looseInterface),
    "_looseObject": (()=>_looseObject),
    "_lowercase": (()=>_lowercase),
    "_lt": (()=>_lt),
    "_lte": (()=>_lte),
    "_map": (()=>_map),
    "_max": (()=>_lte),
    "_maxLength": (()=>_maxLength),
    "_maxSize": (()=>_maxSize),
    "_mime": (()=>_mime),
    "_min": (()=>_gte),
    "_minLength": (()=>_minLength),
    "_minSize": (()=>_minSize),
    "_multipleOf": (()=>_multipleOf),
    "_nan": (()=>_nan),
    "_nanoid": (()=>_nanoid),
    "_nativeEnum": (()=>_nativeEnum),
    "_negative": (()=>_negative),
    "_never": (()=>_never),
    "_nonnegative": (()=>_nonnegative),
    "_nonoptional": (()=>_nonoptional),
    "_nonpositive": (()=>_nonpositive),
    "_normalize": (()=>_normalize),
    "_null": (()=>_null),
    "_nullable": (()=>_nullable),
    "_number": (()=>_number),
    "_object": (()=>_object),
    "_optional": (()=>_optional),
    "_overwrite": (()=>_overwrite),
    "_pipe": (()=>_pipe),
    "_positive": (()=>_positive),
    "_promise": (()=>_promise),
    "_property": (()=>_property),
    "_readonly": (()=>_readonly),
    "_record": (()=>_record),
    "_refine": (()=>_refine),
    "_regex": (()=>_regex),
    "_set": (()=>_set),
    "_size": (()=>_size),
    "_startsWith": (()=>_startsWith),
    "_strictInterface": (()=>_strictInterface),
    "_strictObject": (()=>_strictObject),
    "_string": (()=>_string),
    "_stringbool": (()=>_stringbool),
    "_success": (()=>_success),
    "_symbol": (()=>_symbol),
    "_templateLiteral": (()=>_templateLiteral),
    "_toLowerCase": (()=>_toLowerCase),
    "_toUpperCase": (()=>_toUpperCase),
    "_transform": (()=>_transform),
    "_trim": (()=>_trim),
    "_tuple": (()=>_tuple),
    "_uint32": (()=>_uint32),
    "_uint64": (()=>_uint64),
    "_ulid": (()=>_ulid),
    "_undefined": (()=>_undefined),
    "_union": (()=>_union),
    "_unknown": (()=>_unknown),
    "_uppercase": (()=>_uppercase),
    "_url": (()=>_url),
    "_uuid": (()=>_uuid),
    "_uuidv4": (()=>_uuidv4),
    "_uuidv6": (()=>_uuidv6),
    "_uuidv7": (()=>_uuidv7),
    "_void": (()=>_void),
    "_xid": (()=>_xid)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
;
;
;
function _string(Class, params) {
    return new Class({
        type: "string",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _coercedString(Class, params) {
    return new Class({
        type: "string",
        coerce: true,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _email(Class, params) {
    return new Class({
        type: "string",
        format: "email",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _guid(Class, params) {
    return new Class({
        type: "string",
        format: "guid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uuid(Class, params) {
    return new Class({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uuidv4(Class, params) {
    return new Class({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: false,
        version: "v4",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uuidv6(Class, params) {
    return new Class({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: false,
        version: "v6",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uuidv7(Class, params) {
    return new Class({
        type: "string",
        format: "uuid",
        check: "string_format",
        abort: false,
        version: "v7",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _url(Class, params) {
    return new Class({
        type: "string",
        format: "url",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _emoji(Class, params) {
    return new Class({
        type: "string",
        format: "emoji",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _nanoid(Class, params) {
    return new Class({
        type: "string",
        format: "nanoid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _cuid(Class, params) {
    return new Class({
        type: "string",
        format: "cuid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _cuid2(Class, params) {
    return new Class({
        type: "string",
        format: "cuid2",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _ulid(Class, params) {
    return new Class({
        type: "string",
        format: "ulid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _xid(Class, params) {
    return new Class({
        type: "string",
        format: "xid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _ksuid(Class, params) {
    return new Class({
        type: "string",
        format: "ksuid",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _ipv4(Class, params) {
    return new Class({
        type: "string",
        format: "ipv4",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _ipv6(Class, params) {
    return new Class({
        type: "string",
        format: "ipv6",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _cidrv4(Class, params) {
    return new Class({
        type: "string",
        format: "cidrv4",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _cidrv6(Class, params) {
    return new Class({
        type: "string",
        format: "cidrv6",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _base64(Class, params) {
    return new Class({
        type: "string",
        format: "base64",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _base64url(Class, params) {
    return new Class({
        type: "string",
        format: "base64url",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _e164(Class, params) {
    return new Class({
        type: "string",
        format: "e164",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _jwt(Class, params) {
    return new Class({
        type: "string",
        format: "jwt",
        check: "string_format",
        abort: false,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _isoDateTime(Class, params) {
    return new Class({
        type: "string",
        format: "datetime",
        check: "string_format",
        offset: false,
        local: false,
        precision: null,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _isoDate(Class, params) {
    return new Class({
        type: "string",
        format: "date",
        check: "string_format",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _isoTime(Class, params) {
    return new Class({
        type: "string",
        format: "time",
        check: "string_format",
        precision: null,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _isoDuration(Class, params) {
    return new Class({
        type: "string",
        format: "duration",
        check: "string_format",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _number(Class, params) {
    return new Class({
        type: "number",
        checks: [],
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _coercedNumber(Class, params) {
    return new Class({
        type: "number",
        coerce: true,
        checks: [],
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _int(Class, params) {
    return new Class({
        type: "number",
        check: "number_format",
        abort: false,
        format: "safeint",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _float32(Class, params) {
    return new Class({
        type: "number",
        check: "number_format",
        abort: false,
        format: "float32",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _float64(Class, params) {
    return new Class({
        type: "number",
        check: "number_format",
        abort: false,
        format: "float64",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _int32(Class, params) {
    return new Class({
        type: "number",
        check: "number_format",
        abort: false,
        format: "int32",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uint32(Class, params) {
    return new Class({
        type: "number",
        check: "number_format",
        abort: false,
        format: "uint32",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _boolean(Class, params) {
    return new Class({
        type: "boolean",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _coercedBoolean(Class, params) {
    return new Class({
        type: "boolean",
        coerce: true,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _bigint(Class, params) {
    return new Class({
        type: "bigint",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _coercedBigint(Class, params) {
    return new Class({
        type: "bigint",
        coerce: true,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _int64(Class, params) {
    return new Class({
        type: "bigint",
        check: "bigint_format",
        abort: false,
        format: "int64",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uint64(Class, params) {
    return new Class({
        type: "bigint",
        check: "bigint_format",
        abort: false,
        format: "uint64",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _symbol(Class, params) {
    return new Class({
        type: "symbol",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _undefined(Class, params) {
    return new Class({
        type: "undefined",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _null(Class, params) {
    return new Class({
        type: "null",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _any(Class, params) {
    return new Class({
        type: "any",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _unknown(Class, params) {
    return new Class({
        type: "unknown",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _never(Class, params) {
    return new Class({
        type: "never",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _void(Class, params) {
    return new Class({
        type: "void",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _date(Class, params) {
    return new Class({
        type: "date",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _coercedDate(Class, params) {
    return new Class({
        type: "date",
        coerce: true,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _nan(Class, params) {
    return new Class({
        type: "nan",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _lt(value, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckLessThan"]({
        check: "less_than",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        value,
        inclusive: false
    });
}
function _lte(value, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckLessThan"]({
        check: "less_than",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        value,
        inclusive: true
    });
}
;
function _gt(value, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckGreaterThan"]({
        check: "greater_than",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        value,
        inclusive: false
    });
}
function _gte(value, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckGreaterThan"]({
        check: "greater_than",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        value,
        inclusive: true
    });
}
;
function _positive(params) {
    return _gt(0, params);
}
function _negative(params) {
    return _lt(0, params);
}
function _nonpositive(params) {
    return _lte(0, params);
}
function _nonnegative(params) {
    return _gte(0, params);
}
function _multipleOf(value, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMultipleOf"]({
        check: "multiple_of",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        value
    });
}
function _maxSize(maximum, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMaxSize"]({
        check: "max_size",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        maximum
    });
}
function _minSize(minimum, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMinSize"]({
        check: "min_size",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        minimum
    });
}
function _size(size, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckSizeEquals"]({
        check: "size_equals",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        size
    });
}
function _maxLength(maximum, params) {
    const ch = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMaxLength"]({
        check: "max_length",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        maximum
    });
    return ch;
}
function _minLength(minimum, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMinLength"]({
        check: "min_length",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        minimum
    });
}
function _length(length, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckLengthEquals"]({
        check: "length_equals",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        length
    });
}
function _regex(pattern, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckRegex"]({
        check: "string_format",
        format: "regex",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        pattern
    });
}
function _lowercase(params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckLowerCase"]({
        check: "string_format",
        format: "lowercase",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _uppercase(params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckUpperCase"]({
        check: "string_format",
        format: "uppercase",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _includes(includes, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckIncludes"]({
        check: "string_format",
        format: "includes",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        includes
    });
}
function _startsWith(prefix, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckStartsWith"]({
        check: "string_format",
        format: "starts_with",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        prefix
    });
}
function _endsWith(suffix, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckEndsWith"]({
        check: "string_format",
        format: "ends_with",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params),
        suffix
    });
}
function _property(property, schema, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckProperty"]({
        check: "property",
        property,
        schema,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _mime(types, params) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckMimeType"]({
        check: "mime_type",
        mime: types,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _overwrite(tx) {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodCheckOverwrite"]({
        check: "overwrite",
        tx
    });
}
function _normalize(form) {
    return _overwrite((input)=>input.normalize(form));
}
function _trim() {
    return _overwrite((input)=>input.trim());
}
function _toLowerCase() {
    return _overwrite((input)=>input.toLowerCase());
}
function _toUpperCase() {
    return _overwrite((input)=>input.toUpperCase());
}
function _array(Class, element, params) {
    return new Class({
        type: "array",
        element,
        // get element() {
        //   return element;
        // },
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _interface(Class, shape, params) {
    const cleaned = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cached"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanInterfaceShape"])(shape));
    const def = {
        type: "interface",
        get shape () {
            const _shape = cleaned.value.shape;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignProp"])(this, "shape", _shape);
            return _shape;
        // return cleaned.value.shape;
        },
        get optional () {
            return cleaned.value.optional;
        },
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    };
    return new Class(def);
}
function _strictInterface(Class, shape, params) {
    const cleaned = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cached"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanInterfaceShape"])(shape));
    const def = {
        type: "interface",
        get shape () {
            const _shape = cleaned.value.shape;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignProp"])(this, "shape", _shape);
            return _shape;
        // return cleaned.value.shape;
        },
        get optional () {
            return cleaned.value.optional;
        },
        catchall: _never(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodNever"]),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    };
    return new Class(def);
}
function _looseInterface(Class, shape, params) {
    const cleaned = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cached"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cleanInterfaceShape"])(shape));
    const def = {
        type: "interface",
        get optional () {
            return cleaned.value.optional;
        },
        get shape () {
            const _shape = cleaned.value.shape;
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["assignProp"])(this, "shape", _shape);
            return _shape;
        // return cleaned.value.shape;
        },
        catchall: _unknown(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodUnknown"]),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    };
    return new Class(def);
}
function _object(Class, shape, params) {
    const def = {
        type: "object",
        shape: shape ?? {},
        get optional () {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionalObjectKeys"])(shape ?? {});
        },
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    };
    return new Class(def);
}
function _strictObject(Class, shape, params) {
    return new Class({
        type: "object",
        shape: shape,
        get optional () {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionalObjectKeys"])(shape);
        },
        catchall: _never(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodNever"]),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _looseObject(Class, shape, params) {
    return new Class({
        type: "object",
        shape: shape,
        get optional () {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["optionalObjectKeys"])(shape);
        },
        catchall: _unknown(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodUnknown"]),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _union(Class, options, params) {
    return new Class({
        type: "union",
        options,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _discriminatedUnion(Class, options, params) {
    return new Class({
        type: "union",
        options,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _intersection(Class, left, right, params) {
    return new Class({
        type: "intersection",
        left,
        right,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _tuple(Class, items, _paramsOrRest, _params) {
    const hasRest = _paramsOrRest instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodType"];
    const params = hasRest ? _params : _paramsOrRest;
    const rest = hasRest ? _paramsOrRest : null;
    return new Class({
        type: "tuple",
        items,
        rest,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _record(Class, keyType, valueType, params) {
    return new Class({
        type: "record",
        keyType,
        valueType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _map(Class, keyType, valueType, params) {
    return new Class({
        type: "map",
        keyType,
        valueType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _set(Class, valueType, params) {
    return new Class({
        type: "set",
        valueType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _enum(Class, values, params) {
    const entries = Array.isArray(values) ? Object.fromEntries(values.map((v)=>[
            v,
            v
        ])) : values;
    // if (Array.isArray(values)) {
    //   for (const value of values) {
    //     entries[value] = value;
    //   }
    // } else {
    //   Object.assign(entries, values);
    // }
    // const entries: util.EnumLike = {};
    // for (const val of values) {
    //   entries[val] = val;
    // }
    return new Class({
        type: "enum",
        entries,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _nativeEnum(Class, entries, params) {
    return new Class({
        type: "enum",
        entries,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _literal(Class, value, params) {
    return new Class({
        type: "literal",
        values: Array.isArray(value) ? value : [
            value
        ],
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _file(Class, params) {
    return new Class({
        type: "file",
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _transform(Class, fn, params) {
    return new Class({
        type: "transform",
        transform: fn,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _optional(Class, innerType, params) {
    return new Class({
        type: "optional",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _nullable(Class, innerType, params) {
    return new Class({
        type: "nullable",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _default(Class, innerType, defaultValue, params) {
    return new Class({
        type: "default",
        defaultValue: typeof defaultValue === "function" ? defaultValue : ()=>defaultValue,
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _nonoptional(Class, innerType, params) {
    return new Class({
        type: "nonoptional",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _success(Class, innerType, params) {
    return new Class({
        type: "success",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _catch(Class, innerType, catchValue, params) {
    return new Class({
        type: "catch",
        innerType,
        catchValue: typeof catchValue === "function" ? catchValue : ()=>catchValue,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _pipe(Class, in_, out, params) {
    return new Class({
        type: "pipe",
        in: in_,
        out,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _readonly(Class, innerType, params) {
    return new Class({
        type: "readonly",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _templateLiteral(Class, parts, params) {
    return new Class({
        type: "template_literal",
        parts,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _lazy(Class, getter, params) {
    return new Class({
        type: "lazy",
        getter,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _promise(Class, innerType, params) {
    return new Class({
        type: "promise",
        innerType,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(params)
    });
}
function _custom(Class, fn, _params) {
    const schema = new Class({
        type: "custom",
        check: "custom",
        fn: fn,
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(_params)
    });
    return schema;
}
function _refine(Class, fn, _params = {}) {
    return _custom(Class, fn, _params);
}
function _stringbool(Classes, _params) {
    const params = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["normalizeParams"])(_params);
    const trueValues = new Set(params?.truthy ?? [
        "true",
        "1",
        "yes",
        "on",
        "y",
        "enabled"
    ]);
    const falseValues = new Set(params?.falsy ?? [
        "false",
        "0",
        "no",
        "off",
        "n",
        "disabled"
    ]);
    const _Pipe = Classes.Pipe ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodPipe"];
    const _Boolean = Classes.Boolean ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodBoolean"];
    const _Unknown = Classes.Unknown ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodUnknown"];
    const inst = new _Unknown({
        type: "unknown",
        checks: [
            {
                _zod: {
                    check: (ctx)=>{
                        if (typeof ctx.value === "string") {
                            let data = ctx.value;
                            if (params?.case !== "sensitive") data = data.toLowerCase();
                            if (trueValues.has(data)) {
                                ctx.value = true;
                            } else if (falseValues.has(data)) {
                                ctx.value = false;
                            } else {
                                ctx.issues.push({
                                    code: "invalid_value",
                                    expected: "stringbool",
                                    values: [
                                        ...trueValues,
                                        ...falseValues
                                    ],
                                    input: ctx.value,
                                    inst
                                });
                            }
                        } else {
                            ctx.issues.push({
                                code: "invalid_type",
                                expected: "string",
                                input: ctx.value
                            });
                        }
                    },
                    def: {
                        check: "custom"
                    },
                    onattach: []
                }
            }
        ]
    });
    return new _Pipe({
        type: "pipe",
        in: inst,
        out: new _Boolean({
            type: "boolean"
        })
    });
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/function.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "$ZodFunction": (()=>$ZodFunction),
    "function": (()=>_function)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <locals>");
;
;
;
;
class $ZodFunction {
    constructor(def){
        this._def = def;
    }
    implement(func) {
        if (typeof func !== "function") {
            throw new Error("implement() must be called with a function");
        }
        return (...args)=>{
            const parsedArgs = this._def.input ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(this._def.input, args) : args;
            if (!Array.isArray(parsedArgs)) {
                throw new Error("Invalid arguments schema: not an array or tuple schema.");
            }
            const output = func(...parsedArgs);
            return this._def.output ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parse"])(this._def.output, output) : output;
        };
    }
    implementAsync(func) {
        if (typeof func !== "function") {
            throw new Error("implement() must be called with a function");
        }
        return async (...args)=>{
            const parsedArgs = this._def.input ? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAsync"])(this._def.input, args) : args;
            if (!Array.isArray(parsedArgs)) {
                throw new Error("Invalid arguments schema: not an array or tuple schema.");
            }
            const output = await func(...parsedArgs);
            return this._def.output ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseAsync"])(this._def.output, output) : output;
        };
    }
    input(...args) {
        if (Array.isArray(args[0])) {
            return new $ZodFunction({
                type: "function",
                input: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodTuple"]({
                    type: "tuple",
                    items: args[0],
                    rest: args[1]
                }),
                output: this._def.output
            });
        }
        return new $ZodFunction({
            type: "function",
            input: args[0],
            output: this._def.output
        });
    }
    output(output) {
        return new $ZodFunction({
            type: "function",
            input: this._def.input,
            output
        });
    }
}
function _function(params) {
    return new $ZodFunction({
        type: "function",
        input: Array.isArray(params?.input) ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["_tuple"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["$ZodTuple"], params?.input) : params?.input ?? null,
        output: params?.output ?? null
    });
}
;
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/to-json-schema.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "JSONSchemaGenerator": (()=>JSONSchemaGenerator),
    "toJSONSchema": (()=>toJSONSchema)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$registries$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/registries.js [app-client] (ecmascript)");
;
const formatMap = {
    guid: "uuid",
    url: "uri",
    datetime: "date-time",
    json_string: "json-string"
};
class JSONSchemaGenerator {
    constructor(params){
        this.counter = 0;
        // this.external = params?.external;
        this.metadataRegistry = params?.metadata ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$registries$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["globalRegistry"];
        this.target = params?.target ?? "draft-2020-12";
        this.unrepresentable = params?.unrepresentable ?? "throw";
        this.override = params?.override ?? (()=>{});
        this.io = params?.io ?? "output";
        this.seen = new Map();
    }
    process(schema, _params = {
        path: [],
        schemaPath: []
    }) {
        const def = schema._zod.def;
        // if (def.type === "lazy") {
        //   return this.process((schema as schemas.$ZodLazy)._zod._getter, _params);
        // } else if (def.type === "promise") {
        //   return this.process(def.innerType, _params);
        // } else if (def.type === "pipe") {
        //   return this.process(def.out, _params);
        // }
        // check for schema in seens
        const seen = this.seen.get(schema);
        if (seen) {
            seen.count++;
            // check if cycle
            const isCycle = _params.schemaPath.includes(schema);
            if (isCycle) {
                seen.cycle = _params.path;
            }
            seen.count++;
            // break cycle
            return seen.schema;
        }
        // initialize
        const result = {
            schema: {},
            cached: {},
            count: 1,
            cycle: undefined
        };
        this.seen.set(schema, result);
        if (schema._zod.toJSONSchema) {
            // custom method overrides default behavior
            result.schema = schema._zod.toJSONSchema();
        // return
        }
        const _json = result.schema;
        // check if external
        // const ext = this.external?.registry.get(schema)?.id;
        // if (ext) {
        //   result.external = ext;
        // }
        // metadata
        const meta = this.metadataRegistry.get(schema);
        if (meta) {
            Object.assign(_json, meta);
        // schema exists in registry. add to $defs.
        // if (meta.id) _json.id = meta.id;
        // if (meta.description) _json.description = meta.description;
        // if (meta.title) _json.title = meta.title;
        // if (meta.examples) _json.examples = meta.examples;
        // if (meta.example) _json.examples = [meta.example];
        }
        // const def = (schema as schemas.$ZodTypes)._zod.def;
        const params = {
            ..._params,
            schemaPath: [
                ..._params.schemaPath,
                schema
            ],
            path: _params.path
        };
        switch(def.type){
            case "string":
                {
                    const json = _json;
                    json.type = "string";
                    const { minimum, maximum, format, pattern, contentEncoding } = schema._zod.computed;
                    if (minimum) json.minLength = minimum;
                    if (maximum) json.maxLength = maximum;
                    // custom pattern overrides format
                    if (format) {
                        json.format = formatMap[format] ?? format;
                    }
                    if (pattern) {
                        json.pattern = pattern.source;
                    }
                    if (contentEncoding) json.contentEncoding = contentEncoding;
                    break;
                }
            case "number":
                {
                    const json = _json;
                    const { minimum, maximum, format, multipleOf, inclusive } = schema._zod.computed;
                    if (format?.includes("int")) json.type = "integer";
                    else json.type = "number";
                    if (minimum) {
                        if (inclusive) json.minimum = minimum;
                        else json.exclusiveMinimum = minimum;
                    }
                    if (maximum) {
                        if (inclusive) json.maximum = maximum;
                        else json.exclusiveMaximum = maximum;
                    }
                    if (multipleOf) json.multipleOf = multipleOf;
                    break;
                }
            case "boolean":
                {
                    const json = _json;
                    json.type = "boolean";
                    break;
                }
            case "bigint":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("BigInt cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "symbol":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Symbols cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "undefined":
                {
                    const json = _json;
                    json.type = "null";
                    break;
                }
            case "null":
                {
                    _json.type = "null";
                    break;
                }
            case "any":
                {
                    break;
                }
            case "unknown":
                {
                    break;
                }
            case "never":
                {
                    _json.not = {};
                    break;
                }
            case "void":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Void cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "date":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Date cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "array":
                {
                    const json = _json;
                    const { minimum, maximum } = schema._zod.computed;
                    if (minimum) json.minItems = minimum;
                    if (maximum) json.maxItems = maximum;
                    json.type = "array";
                    json.items = this.process(def.element, {
                        ...params,
                        path: [
                            ...params.path,
                            "items"
                        ]
                    });
                    break;
                }
            case "object":
            case "interface":
                {
                    const json = _json;
                    json.type = "object";
                    json.properties = {};
                    const shape = def.shape; // params.shapeCache.get(schema)!;
                    // if (!shape) {
                    //   shape = def.shape;
                    //   params.shapeCache.set(schema, shape);
                    // }
                    for(const key in shape){
                        json.properties[key] = this.process(shape[key], {
                            ...params,
                            path: [
                                ...params.path,
                                "properties",
                                key
                            ]
                        });
                    }
                    // required keys
                    const allKeys = new Set(Object.keys(shape));
                    const optionalKeys = new Set(def.optional);
                    const requiredKeys = new Set([
                        ...allKeys
                    ].filter((key)=>!optionalKeys.has(key)));
                    json.required = Array.from(requiredKeys);
                    // catchall
                    if (def.catchall) {
                        json.additionalProperties = this.process(def.catchall, {
                            ...params,
                            path: [
                                ...params.path,
                                "additionalProperties"
                            ]
                        });
                    }
                    break;
                }
            case "union":
                {
                    const json = _json;
                    json.anyOf = def.options.map((x, i)=>this.process(x, {
                            ...params,
                            path: [
                                ...params.path,
                                "anyOf",
                                i
                            ]
                        }));
                    break;
                }
            case "intersection":
                {
                    const json = _json;
                    json.allOf = [
                        this.process(def.left, {
                            ...params,
                            path: [
                                ...params.path,
                                "allOf",
                                0
                            ]
                        }),
                        this.process(def.right, {
                            ...params,
                            path: [
                                ...params.path,
                                "allOf",
                                1
                            ]
                        })
                    ];
                    break;
                }
            case "tuple":
                {
                    const json = _json;
                    json.type = "array";
                    const prefixItems = def.items.map((x, i)=>this.process(x, {
                            ...params,
                            path: [
                                ...params.path,
                                "prefixItems",
                                i
                            ]
                        }));
                    if (this.target === "draft-2020-12") {
                        json.prefixItems = prefixItems;
                    } else {
                        json.items = prefixItems;
                    }
                    if (def.rest) {
                        const rest = this.process(def.rest, {
                            ...params,
                            path: [
                                ...params.path,
                                "items"
                            ]
                        });
                        if (this.target === "draft-2020-12") {
                            json.items = rest;
                        } else {
                            json.additionalItems = rest;
                        }
                    }
                    // additionalItems
                    if (def.rest) {
                        json.items = this.process(def.rest, {
                            ...params,
                            path: [
                                ...params.path,
                                "items"
                            ]
                        });
                    }
                    // length
                    const { minimum, maximum } = schema._zod.computed;
                    if (minimum) json.minItems = minimum;
                    if (maximum) json.maxItems = maximum;
                    break;
                }
            case "record":
                {
                    const json = _json;
                    json.type = "object";
                    json.propertyNames = this.process(def.keyType, {
                        ...params,
                        path: [
                            ...params.path,
                            "propertyNames"
                        ]
                    });
                    json.additionalProperties = this.process(def.valueType, {
                        ...params,
                        path: [
                            ...params.path,
                            "additionalProperties"
                        ]
                    });
                    break;
                }
            case "map":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Map cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "set":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Set cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "enum":
                {
                    const json = _json;
                    json.enum = Object.values(def.entries);
                    break;
                }
            case "literal":
                {
                    const json = _json;
                    const vals = [];
                    for (const val of def.values){
                        if (val === undefined) {
                            if (this.unrepresentable === "throw") {
                                throw new Error("Literal `undefined` cannot be represented in JSON Schema");
                            } else {
                            // do not add to vals
                            }
                        } else if (typeof val === "bigint") {
                            if (this.unrepresentable === "throw") {
                                throw new Error("BigInt literals cannot be represented in JSON Schema");
                            } else {
                                vals.push(Number(val));
                            }
                        } else {
                            vals.push(val);
                        }
                    }
                    if (vals.length === 0) {
                    // do nothing (an undefined literal was stripped)
                    } else if (vals.length === 1) {
                        const val = vals[0];
                        json.const = val;
                    } else {
                        json.enum = vals;
                    }
                    break;
                }
            case "file":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("File cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "transform":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Transforms cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "nullable":
                {
                    const inner = this.process(def.innerType, params);
                    _json.anyOf = [
                        inner,
                        {
                            type: "null"
                        }
                    ];
                    break;
                }
            case "nonoptional":
                {
                    const inner = this.process(def.innerType, params);
                    Object.assign(_json, inner);
                    break;
                }
            case "success":
                {
                    const json = _json;
                    json.type = "boolean";
                    break;
                }
            case "default":
                {
                    const inner = this.process(def.innerType, params);
                    Object.assign(_json, inner);
                    _json.default = def.defaultValue();
                    break;
                }
            case "catch":
                {
                    // use conditionals
                    const inner = this.process(def.innerType, params);
                    Object.assign(_json, inner);
                    let catchValue;
                    try {
                        catchValue = def.catchValue(undefined);
                    } catch  {
                        throw new Error("Dynamic catch values are not supported in JSON Schema");
                    }
                    _json.default = catchValue;
                    break;
                }
            case "nan":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("NaN cannot be represented in JSON Schema");
                    }
                    break;
                }
            case "pipe":
                {
                    const innerType = this.io === "input" ? def.in : def.out;
                    const inner = this.process(innerType, params);
                    result.schema = inner;
                    break;
                }
            case "readonly":
                {
                    const inner = this.process(def.innerType, params);
                    Object.assign(_json, inner);
                    // _json.allOf = [inner];
                    _json.readOnly = true;
                    break;
                }
            case "template_literal":
                {
                    const json = _json;
                    const pattern = schema._zod.pattern;
                    if (!pattern) throw new Error("Pattern not found in template literal");
                    json.type = "string";
                    json.pattern = pattern.source;
                    break;
                }
            case "promise":
                {
                    const inner = this.process(def.innerType, params);
                    result.schema = inner;
                    break;
                }
            // passthrough types
            case "optional":
                {
                    const inner = this.process(def.innerType, params);
                    result.schema = inner;
                    break;
                }
            case "lazy":
                {
                    const innerType = schema._zod._getter;
                    const inner = this.process(innerType, params);
                    result.schema = inner;
                    break;
                }
            case "custom":
                {
                    if (this.unrepresentable === "throw") {
                        throw new Error("Custom types cannot be represented in JSON Schema");
                    }
                    break;
                }
            default:
                {
                    def;
                }
        }
        // pulling fresh from this.seen in case it was overwritten
        const _result = this.seen.get(schema);
        this.override({
            zodSchema: schema,
            jsonSchema: _result.schema
        });
        Object.assign(_result.cached, _result.schema);
        return _result.schema;
    }
    emit(schema, _params) {
        const params = {
            cycles: _params?.cycles ?? "ref",
            reused: _params?.reused ?? "inline",
            // unrepresentable: _params?.unrepresentable ?? "throw",
            // uri: _params?.uri ?? ((id) => `${id}`),
            external: _params?.external ?? undefined
        };
        // iterate over seen map
        const result = {};
        const defs = params.external?.defs ?? {};
        const seen = this.seen.get(schema);
        if (!seen) throw new Error("Unprocessed schema. This is a bug in Zod.");
        Object.assign(result, seen.cached);
        const makeURI = (entry)=>{
            // comparing the seen objects because sometimes
            // multiple schemas map to the same seen object.
            // e.g. lazy
            if (entry[1] === seen) {
                return {
                    ref: "#"
                };
            }
            // external is configured
            const defsSegment = this.target === "draft-2020-12" ? "$defs" : "definitions";
            if (params.external) {
                const externalId = params.external.registry.get(entry[0])?.id; // ?? "__shared";// `__schema${this.counter++}`;
                if (externalId) return {
                    ref: params.external.uri(externalId)
                };
                const id = entry[1].defId ?? entry[1].schema.id ?? `schema${this.counter++}`;
                entry[1].defId = id;
                return {
                    defId: id,
                    ref: `${params.external.uri("__shared")}#/${defsSegment}/${id}`
                };
            }
            // self-contained schema
            const uriPrefix = `#`;
            const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
            const defId = entry[1].schema.id ?? `__schema${this.counter++}`;
            return {
                defId,
                ref: defUriPrefix + defId
            };
        };
        for (const entry of this.seen.entries()){
            const seen = entry[1];
            if (schema === entry[0]) {
                schemaToRef({
                    schema: seen.schema,
                    ref: "#"
                });
                continue;
            }
            // external
            if (params.external) {
                const ext = params.external.registry.get(entry[0])?.id;
                if (schema !== entry[0] && ext) {
                    // does not write to defs
                    const { ref, defId } = makeURI(entry); // params.external.uri(ext);
                    if (defId) defs[defId] = {
                        ...seen.cached
                    };
                    schemaToRef({
                        schema: seen.schema,
                        ref
                    });
                    continue;
                }
            }
            // handle schemas with `id`
            const id = this.metadataRegistry.get(entry[0])?.id;
            if (id) {
                const { ref, defId } = makeURI(entry);
                if (defId) defs[defId] = {
                    ...seen.cached
                };
                schemaToRef({
                    schema: seen.schema,
                    ref
                });
                continue;
            }
            // handle cycles
            if (seen.cycle) {
                if (params.cycles === "throw") {
                    throw new Error("Cycle detected: " + `#/${seen.cycle?.join("/")}/<root>` + '\n\nSet the `cycles` parameter to `"ref"` to resolve cyclical schemas with defs.');
                } else if (params.cycles === "ref") {
                    const { ref, defId } = makeURI(entry); // schema === entry[0] ? "#" : defUriPrefix + id;
                    if (defId) defs[defId] = {
                        ...seen.cached
                    };
                    schemaToRef({
                        schema: seen.schema,
                        ref
                    });
                }
                continue;
            }
            // handle reused schemas
            if (seen.count > 1) {
                if (params.reused === "ref") {
                    const { ref, defId } = makeURI(entry);
                    if (defId) defs[defId] = {
                        ...seen.cached
                    };
                    schemaToRef({
                        schema: seen.schema,
                        ref
                    });
                    continue;
                }
            }
        }
        if (!params.external && Object.keys(defs).length > 0) {
            if (this.target === "draft-2020-12") {
                result.$defs = defs;
            } else {
                result.definitions = defs;
            }
        }
        try {
            // this essentially "finalizes" this schema
            // each call to .emit() is functionally independent
            // though the seen map is shared
            return JSON.parse(JSON.stringify(result));
        } catch (_err) {
            console.log(_err);
            throw new Error("Error converting schema to JSON.");
        }
    }
}
function schemaToRef(params) {
    const { schema, ref } = params;
    for(const key in schema){
        delete schema[key];
        schema.$ref = ref;
    }
}
function toJSONSchema(input, _params) {
    if (input instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$registries$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["$ZodRegistry"]) {
        const gen = new JSONSchemaGenerator(_params);
        const defs = {};
        for (const entry of input._idmap.entries()){
            const [_, schema] = entry;
            gen.process(schema);
        }
        const schemas = {};
        const external = {
            registry: input,
            uri: _params?.uri || ((id)=>id),
            defs
        };
        for (const entry of input._idmap.entries()){
            const [key, schema] = entry;
            schemas[key] = gen.emit(schema, {
                ..._params,
                external
            });
        }
        if (Object.keys(defs).length > 0) {
            const defsSegment = gen.target === "draft-2020-12" ? "$defs" : "definitions";
            schemas.__shared = {
                [defsSegment]: defs
            };
        }
        return {
            schemas
        };
    }
    const gen = new JSONSchemaGenerator(_params);
    gen.process(input);
    // console.log(gen.seen);
    return gen.emit(input, _params);
}
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/json-schema.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
;
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/index.js [app-client] (ecmascript) <locals>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$versions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/versions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$registries$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/registries.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$function$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/function.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$to$2d$json$2d$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/to-json-schema.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$json$2d$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/json-schema.js [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/index.js [app-client] (ecmascript) <module evaluation>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$core$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/core.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$parse$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/parse.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$errors$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/errors.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$schemas$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/schemas.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$checks$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/checks.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$versions$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/versions.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$regexes$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/regexes.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$locales$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/locales.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$registries$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/registries.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$doc$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/doc.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$function$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/function.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$to$2d$json$2d$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/to-json-schema.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$json$2d$schema$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/json-schema.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/index.js [app-client] (ecmascript) <locals>");
}}),
"[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript) <export * as util>": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "util": (()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$zod$2b$core$40$0$2e$8$2e$1$2f$node_modules$2f40$zod$2f$core$2f$dist$2f$esm$2f$util$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@zod+core@0.8.1/node_modules/@zod/core/dist/esm/util.js [app-client] (ecmascript)");
}}),
}]);

//# sourceMappingURL=a7cec_%40zod_core_dist_esm_8a178cb4._.js.map