(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/9c939_tailwind-merge_dist_bundle-mjs_mjs_5274cb0a._.js",
  "static/chunks/1f510_@daveyplate_better-auth-ui_dist_c44674c7._.js",
  "static/chunks/2ec82_@react-email_tailwind_dist_index_mjs_a378303e._.js",
  "static/chunks/7ce1f_zod_lib_index_mjs_252d6e72._.js",
  "static/chunks/node_modules__pnpm_de69224a._.js",
  "static/chunks/_70f663e3._.js",
  "static/chunks/app_globals_73c37791.css"
],
    source: "dynamic"
});
